import '../controller/cuts_card1_controller.dart';
import 'package:get/get.dart';

class CutsCard1Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => CutsCard1Controller());
  }
}
