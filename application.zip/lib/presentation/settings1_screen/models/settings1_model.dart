class Settings1Model {}
