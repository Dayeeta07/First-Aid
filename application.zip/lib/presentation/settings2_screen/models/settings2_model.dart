class Settings2Model {}
