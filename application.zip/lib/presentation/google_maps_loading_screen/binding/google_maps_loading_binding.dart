import '../controller/google_maps_loading_controller.dart';
import 'package:get/get.dart';

class GoogleMapsLoadingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => GoogleMapsLoadingController());
  }
}
