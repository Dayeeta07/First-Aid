import '/core/app_export.dart';
import 'package:application/presentation/settings2_screen/models/settings2_model.dart';

class Settings2Controller extends GetxController with StateMixin<dynamic> {
  Rx<Settings2Model> settings2ModelObj = Settings2Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
