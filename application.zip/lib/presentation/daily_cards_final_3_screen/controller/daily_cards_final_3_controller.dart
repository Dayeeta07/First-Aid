import '/core/app_export.dart';
import 'package:application/presentation/daily_cards_final_3_screen/models/daily_cards_final_3_model.dart';

class DailyCardsFinal3Controller extends GetxController
    with StateMixin<dynamic> {
  Rx<DailyCardsFinal3Model> dailyCardsFinal3ModelObj =
      DailyCardsFinal3Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
