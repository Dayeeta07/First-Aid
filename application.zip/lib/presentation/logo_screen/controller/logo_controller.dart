import '/core/app_export.dart';
import 'package:application/presentation/logo_screen/models/logo_model.dart';

class LogoController extends GetxController with StateMixin<dynamic> {
  Rx<LogoModel> logoModelObj = LogoModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
