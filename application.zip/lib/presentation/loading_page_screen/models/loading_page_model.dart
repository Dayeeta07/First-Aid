class LoadingPageModel {}
