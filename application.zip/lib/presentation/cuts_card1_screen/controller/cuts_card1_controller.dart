import '/core/app_export.dart';
import 'package:application/presentation/cuts_card1_screen/models/cuts_card1_model.dart';

class CutsCard1Controller extends GetxController with StateMixin<dynamic> {
  Rx<CutsCard1Model> cutsCard1ModelObj = CutsCard1Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
