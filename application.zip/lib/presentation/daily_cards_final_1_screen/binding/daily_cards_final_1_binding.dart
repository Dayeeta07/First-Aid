import '../controller/daily_cards_final_1_controller.dart';
import 'package:get/get.dart';

class DailyCardsFinal1Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DailyCardsFinal1Controller());
  }
}
