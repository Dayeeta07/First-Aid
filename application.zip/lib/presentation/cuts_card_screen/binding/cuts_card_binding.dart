import '../controller/cuts_card_controller.dart';
import 'package:get/get.dart';

class CutsCardBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => CutsCardController());
  }
}
