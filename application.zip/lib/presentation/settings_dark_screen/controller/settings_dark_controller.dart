import '/core/app_export.dart';
import 'package:application/presentation/settings_dark_screen/models/settings_dark_model.dart';

class SettingsDarkController extends GetxController with StateMixin<dynamic> {
  Rx<SettingsDarkModel> settingsDarkModelObj = SettingsDarkModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
