import '../controller/settings2_controller.dart';
import 'package:get/get.dart';

class Settings2Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => Settings2Controller());
  }
}
