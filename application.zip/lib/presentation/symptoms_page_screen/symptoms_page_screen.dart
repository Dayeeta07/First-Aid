import 'controller/symptoms_page_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SymptomsPageScreen extends GetWidget<SymptomsPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Container(
                                            height: getVerticalSize(132.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  132.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  360.00),
                                                          child: SvgPicture.asset(
                                                              ImageConstant
                                                                  .imgMaskgroup2,
                                                              fit: BoxFit
                                                                  .fill))),
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant
                                                                  .red400,
                                                              borderRadius: BorderRadius.only(
                                                                  topLeft: Radius.circular(
                                                                      getHorizontalSize(
                                                                          42.00)),
                                                                  topRight: Radius.circular(
                                                                      getHorizontalSize(
                                                                          42.00)),
                                                                  bottomLeft: Radius.circular(
                                                                      getHorizontalSize(
                                                                          0.00)),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          getHorizontalSize(0.00)))),
                                                          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                            Align(
                                                                alignment: Alignment
                                                                    .centerLeft,
                                                                child: Container(
                                                                    width: size.width,
                                                                    margin: EdgeInsets.only(top: getVerticalSize(26.00), bottom: getVerticalSize(36.00)),
                                                                    child: Padding(
                                                                        padding: EdgeInsets.only(left: getHorizontalSize(9.00), right: getHorizontalSize(16.00)),
                                                                        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.max, children: [
                                                                          Container(
                                                                              height: getSize(53.00),
                                                                              width: getSize(53.00),
                                                                              margin: EdgeInsets.only(bottom: getVerticalSize(17.00)),
                                                                              child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                Align(alignment: Alignment.center, child: Container(height: getSize(37.00), width: getSize(37.00), margin: EdgeInsets.only(left: getHorizontalSize(9.00), top: getVerticalSize(7.00), right: getHorizontalSize(7.00), bottom: getVerticalSize(9.00)), decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))))),
                                                                                Align(
                                                                                    alignment: Alignment.centerLeft,
                                                                                    child: Container(
                                                                                        height: getSize(53.00),
                                                                                        width: getSize(53.00),
                                                                                        child: Stack(alignment: Alignment.center, children: [
                                                                                          Align(
                                                                                              alignment: Alignment.centerLeft,
                                                                                              child: Container(
                                                                                                  height: getSize(53.00),
                                                                                                  width: getSize(53.00),
                                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                                    Align(
                                                                                                        alignment: Alignment.centerLeft,
                                                                                                        child: Container(
                                                                                                            height: getSize(53.00),
                                                                                                            width: getSize(53.00),
                                                                                                            child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                                              Align(
                                                                                                                  alignment: Alignment.centerLeft,
                                                                                                                  child: Container(
                                                                                                                      height: getSize(53.00),
                                                                                                                      width: getSize(53.00),
                                                                                                                      child: Stack(alignment: Alignment.center, children: [
                                                                                                                        Align(
                                                                                                                            alignment: Alignment.centerLeft,
                                                                                                                            child: GestureDetector(
                                                                                                                                onTap: () {
                                                                                                                                  onTapImgMenuPNG1();
                                                                                                                                },
                                                                                                                                child: Image.asset(ImageConstant.imgMenupng1, height: getSize(53.00), width: getSize(53.00), fit: BoxFit.fill))),
                                                                                                                        Align(alignment: Alignment.center, child: Container(height: getVerticalSize(41.00), width: getHorizontalSize(45.00), margin: EdgeInsets.only(left: getHorizontalSize(5.00), top: getVerticalSize(5.00), right: getHorizontalSize(3.00), bottom: getVerticalSize(7.00)), decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00)))))
                                                                                                                      ]))),
                                                                                                              Align(alignment: Alignment.centerLeft, child: Image.asset(ImageConstant.imgMenupng1, height: getSize(53.00), width: getSize(53.00), fit: BoxFit.fill))
                                                                                                            ]))),
                                                                                                    Align(alignment: Alignment.center, child: Container(height: getSize(37.00), width: getSize(37.00), margin: EdgeInsets.only(left: getHorizontalSize(9.00), top: getVerticalSize(7.00), right: getHorizontalSize(7.00), bottom: getVerticalSize(9.00)), decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50)))))
                                                                                                  ]))),
                                                                                          Align(alignment: Alignment.center, child: Container(height: getVerticalSize(41.00), width: getHorizontalSize(45.00), margin: EdgeInsets.only(left: getHorizontalSize(5.00), top: getVerticalSize(5.00), right: getHorizontalSize(3.00), bottom: getVerticalSize(7.00)), decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00)))))
                                                                                        ])))
                                                                              ])),
                                                                          Padding(
                                                                              padding: EdgeInsets.only(top: getVerticalSize(32.00)),
                                                                              child: Text("lbl_hi_dayeeta_c".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanblack32.copyWith(fontSize: getFontSize(32)))),
                                                                          Container(
                                                                              height: getVerticalSize(41.00),
                                                                              width: getHorizontalSize(45.00),
                                                                              margin: EdgeInsets.only(bottom: getVerticalSize(29.00)),
                                                                              child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                Align(
                                                                                    alignment: Alignment.center,
                                                                                    child: Container(
                                                                                        height: getSize(37.00),
                                                                                        width: getSize(37.00),
                                                                                        margin: EdgeInsets.only(left: getHorizontalSize(4.00), top: getVerticalSize(2.00), right: getHorizontalSize(4.00), bottom: getVerticalSize(2.00)),
                                                                                        decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))),
                                                                                        child: Card(
                                                                                            clipBehavior: Clip.antiAlias,
                                                                                            elevation: 0,
                                                                                            margin: EdgeInsets.all(0),
                                                                                            color: ColorConstant.whiteA700,
                                                                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(getHorizontalSize(18.50))),
                                                                                            child: Stack(children: [
                                                                                              Align(alignment: Alignment.center, child: Padding(padding: EdgeInsets.only(left: getHorizontalSize(1.00), top: getVerticalSize(1.00), right: getHorizontalSize(1.00), bottom: getVerticalSize(0.08)), child: Image.asset(ImageConstant.imgSettingpng1, height: getVerticalSize(35.92), width: getHorizontalSize(35.00), fit: BoxFit.fill)))
                                                                                            ])))),
                                                                                Align(
                                                                                    alignment: Alignment.centerLeft,
                                                                                    child: Container(
                                                                                        decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00))),
                                                                                        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                          Align(
                                                                                              alignment: Alignment.centerLeft,
                                                                                              child: GestureDetector(
                                                                                                  onTap: () {
                                                                                                    onTapRectangle20();
                                                                                                  },
                                                                                                  child: Container(
                                                                                                      width: double.infinity,
                                                                                                      decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00))),
                                                                                                      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.center, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                                        Container(
                                                                                                            height: getSize(37.00),
                                                                                                            width: getSize(37.00),
                                                                                                            margin: EdgeInsets.only(left: getHorizontalSize(4.00), top: getVerticalSize(2.00), right: getHorizontalSize(4.00), bottom: getVerticalSize(2.00)),
                                                                                                            decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))),
                                                                                                            child: Card(
                                                                                                                clipBehavior: Clip.antiAlias,
                                                                                                                elevation: 0,
                                                                                                                margin: EdgeInsets.all(0),
                                                                                                                color: ColorConstant.whiteA700,
                                                                                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(getHorizontalSize(18.50))),
                                                                                                                child: Stack(children: [
                                                                                                                  Align(alignment: Alignment.center, child: Padding(padding: EdgeInsets.only(left: getHorizontalSize(1.00), top: getVerticalSize(1.00), right: getHorizontalSize(1.00), bottom: getVerticalSize(0.08)), child: Image.asset(ImageConstant.imgSettingpng1, height: getVerticalSize(35.92), width: getHorizontalSize(35.00), fit: BoxFit.fill)))
                                                                                                                ])))
                                                                                                      ]))))
                                                                                        ])))
                                                                              ]))
                                                                        ]))))
                                                          ])))
                                                ]))),
                                    Container(
                                        height: getVerticalSize(51.00),
                                        width: getHorizontalSize(327.00),
                                        margin: EdgeInsets.only(
                                            left: getHorizontalSize(16.00),
                                            top: getVerticalSize(22.00),
                                            right: getHorizontalSize(16.00)),
                                        decoration: BoxDecoration(
                                            color: ColorConstant.red400,
                                            borderRadius: BorderRadius.circular(
                                                getHorizontalSize(10.00))),
                                        child: Card(
                                            clipBehavior: Clip.antiAlias,
                                            elevation: 0,
                                            margin: EdgeInsets.all(0),
                                            color: ColorConstant.red400,
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        getHorizontalSize(
                                                            10.00))),
                                            child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Padding(
                                                          padding: EdgeInsets.only(
                                                              left: getHorizontalSize(
                                                                  13.00),
                                                              top: getVerticalSize(
                                                                  16.00),
                                                              right:
                                                                  getHorizontalSize(
                                                                      12.00),
                                                              bottom:
                                                                  getVerticalSize(
                                                                      17.00)),
                                                          child: Text(
                                                              "lbl_emergency"
                                                                  .tr
                                                                  .toUpperCase(),
                                                              overflow:
                                                                  TextOverflow
                                                                      .ellipsis,
                                                              textAlign: TextAlign
                                                                  .center,
                                                              style: AppStyle
                                                                  .textStyleRobotoromansemibold36
                                                                  .copyWith(fontSize: getFontSize(36))))),
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          alignment:
                                                              Alignment.center,
                                                          height:
                                                              getVerticalSize(
                                                                  51.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  327.00),
                                                          decoration: AppDecoration
                                                              .textStyleRobotoromansemibold361,
                                                          child: Text(
                                                              "lbl_symptoms".tr,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: AppStyle
                                                                  .textStyleRobotoromansemibold361
                                                                  .copyWith(
                                                                      fontSize:
                                                                          getFontSize(
                                                                              36)))))
                                                ]))),
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(16.00),
                                                top: getVerticalSize(22.00),
                                                right:
                                                    getHorizontalSize(16.00)),
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(97.00),
                                                width:
                                                    getHorizontalSize(327.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromansemibold241,
                                                child: Text("lbl_fever".tr,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .textStyleRobotoromansemibold241
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    24)))))),
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(16.00),
                                                top: getVerticalSize(22.00),
                                                right:
                                                    getHorizontalSize(16.00)),
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(97.00),
                                                width:
                                                    getHorizontalSize(327.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromansemibold241,
                                                child: Text(
                                                    "lbl_pain_in_chest".tr,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .textStyleRobotoromansemibold241
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    24)))))),
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(17.00),
                                                top: getVerticalSize(22.00),
                                                right:
                                                    getHorizontalSize(16.00)),
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(97.00),
                                                width:
                                                    getHorizontalSize(327.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromansemibold241,
                                                child: Text(
                                                    "lbl_breathlessness".tr,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .textStyleRobotoromansemibold241
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    24)))))),
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(16.00),
                                                top: getVerticalSize(22.00),
                                                right:
                                                    getHorizontalSize(16.00)),
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(97.00),
                                                width:
                                                    getHorizontalSize(327.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromansemibold241,
                                                child: Text(
                                                    "lbl_poor_vision".tr,
                                                    textAlign: TextAlign.left,
                                                    style: AppStyle
                                                        .textStyleRobotoromansemibold241
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    24))))))
                                  ]),
                              Padding(
                                  padding: EdgeInsets.only(
                                      top: getVerticalSize(19.00),
                                      bottom: getVerticalSize(10.00)),
                                  child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                            height: getSize(85.00),
                                            width: getSize(85.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(26.00),
                                                top: getVerticalSize(2.00),
                                                bottom: getVerticalSize(3.00)),
                                            child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getSize(50.00),
                                                          width: getSize(50.00),
                                                          margin: EdgeInsets.only(
                                                              left:
                                                                  getHorizontalSize(
                                                                      17.00),
                                                              top:
                                                                  getVerticalSize(
                                                                      17.00),
                                                              right:
                                                                  getHorizontalSize(
                                                                      18.00),
                                                              bottom:
                                                                  getVerticalSize(
                                                                      18.00)),
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant
                                                                  .deepOrange100,
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(
                                                                          25.00))))),
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          height:
                                                              getSize(85.00),
                                                          width: getSize(85.00),
                                                          child: Stack(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              children: [
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerLeft,
                                                                    child: Image.asset(
                                                                        ImageConstant
                                                                            .imgReturnpng2,
                                                                        height: getSize(
                                                                            85.00),
                                                                        width: getSize(
                                                                            85.00),
                                                                        fit: BoxFit
                                                                            .fill)),
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: GestureDetector(
                                                                        onTap: () {
                                                                          onTapRectangle19();
                                                                        },
                                                                        child: Container(height: getVerticalSize(50.00), width: getHorizontalSize(51.00), margin: EdgeInsets.only(left: getHorizontalSize(16.00), top: getVerticalSize(17.00), right: getHorizontalSize(18.00), bottom: getVerticalSize(18.00)), decoration: BoxDecoration(color: ColorConstant.redA100, borderRadius: BorderRadius.circular(getHorizontalSize(25.00))))))
                                                              ])))
                                                ])),
                                        Container(
                                            height: getSize(90.00),
                                            width: getSize(90.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(24.00)),
                                            decoration: BoxDecoration(
                                                color: ColorConstant.red500,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        getHorizontalSize(
                                                            45.00))),
                                            child: Card(
                                                clipBehavior: Clip.antiAlias,
                                                elevation: 0,
                                                margin: EdgeInsets.all(0),
                                                color: ColorConstant.red500,
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            getHorizontalSize(
                                                                45.00))),
                                                child: Stack(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    children: [
                                                      Align(
                                                          alignment:
                                                              Alignment.center,
                                                          child: Padding(
                                                              padding: EdgeInsets.only(
                                                                  left:
                                                                      getHorizontalSize(
                                                                          17.00),
                                                                  top: getVerticalSize(
                                                                      16.00),
                                                                  right:
                                                                      getHorizontalSize(
                                                                          15.00),
                                                                  bottom:
                                                                      getVerticalSize(
                                                                          16.00)),
                                                              child: ClipRRect(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getSize(
                                                                              29.00)),
                                                                  child: Image.asset(
                                                                      ImageConstant.imgEllipse11,
                                                                      height: getSize(58.00),
                                                                      width: getSize(58.00),
                                                                      fit: BoxFit.fill)))),
                                                      Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child: Container(
                                                              decoration: BoxDecoration(
                                                                  color:
                                                                      ColorConstant
                                                                          .red500,
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              45.00))),
                                                              child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                17.00),
                                                                            top: getVerticalSize(
                                                                                16.00),
                                                                            right: getHorizontalSize(
                                                                                15.00),
                                                                            bottom: getVerticalSize(
                                                                                16.00)),
                                                                        child: ClipRRect(
                                                                            borderRadius: BorderRadius.circular(getSize(
                                                                                29.00)),
                                                                            child: Image.asset(ImageConstant.imgEllipse11,
                                                                                height: getSize(58.00),
                                                                                width: getSize(58.00),
                                                                                fit: BoxFit.fill)))
                                                                  ])))
                                                    ]))),
                                        Container(
                                            height: getVerticalSize(69.00),
                                            width: getHorizontalSize(51.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(41.00),
                                                top: getVerticalSize(9.00),
                                                right: getHorizontalSize(43.00),
                                                bottom: getVerticalSize(12.00)),
                                            child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getSize(50.00),
                                                          width: getSize(50.00),
                                                          margin: EdgeInsets.only(
                                                              left:
                                                                  getHorizontalSize(
                                                                      1.00),
                                                              top:
                                                                  getVerticalSize(
                                                                      10.00),
                                                              bottom:
                                                                  getVerticalSize(
                                                                      9.00)),
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant
                                                                  .deepOrange100,
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(
                                                                          25.00))))),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Padding(
                                                          padding: EdgeInsets.only(
                                                              left:
                                                                  getHorizontalSize(
                                                                      1.00)),
                                                          child: Image.asset(
                                                              ImageConstant
                                                                  .imgMicrophonepng1,
                                                              height:
                                                                  getVerticalSize(
                                                                      69.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      50.00),
                                                              fit: BoxFit
                                                                  .fill))),
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          height: getVerticalSize(
                                                              50.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  51.00),
                                                          margin: EdgeInsets.only(
                                                              top:
                                                                  getVerticalSize(
                                                                      10.00),
                                                              bottom:
                                                                  getVerticalSize(
                                                                      9.00)),
                                                          decoration: BoxDecoration(
                                                              color:
                                                                  ColorConstant
                                                                      .redA100,
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(
                                                                          25.00)))))
                                                ]))
                                      ]))
                            ]))))));
  }

  onTapImgMenuPNG1() {
    Get.toNamed(AppRoutes.menuScreen);
  }

  onTapRectangle20() {
    Get.toNamed(AppRoutes.settings1Screen);
  }

  onTapRectangle19() {
    Get.toNamed(AppRoutes.choosingPageScreen);
  }
}
