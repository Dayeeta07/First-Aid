class SignUpOrLoginModel {}
