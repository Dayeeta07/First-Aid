import '/core/app_export.dart';
import 'package:application/presentation/sign_up_done_screen/models/sign_up_done_model.dart';
import 'package:flutter/material.dart';

class SignUpDoneController extends GetxController with StateMixin<dynamic> {
  TextEditingController dayeetaCController = TextEditingController();

  TextEditingController femaleController = TextEditingController();

  TextEditingController dDMMYYYYController = TextEditingController();

  TextEditingController xXXXXXXXController = TextEditingController();

  TextEditingController firstaidofficiaController = TextEditingController();

  TextEditingController tfController = TextEditingController();

  Rx<SignUpDoneModel> signUpDoneModelObj = SignUpDoneModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
    dayeetaCController.dispose();
    femaleController.dispose();
    dDMMYYYYController.dispose();
    xXXXXXXXController.dispose();
    firstaidofficiaController.dispose();
    tfController.dispose();
  }
}
