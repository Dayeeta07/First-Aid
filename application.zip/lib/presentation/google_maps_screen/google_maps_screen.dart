import 'controller/google_maps_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class GoogleMapsScreen extends GetWidget<GoogleMapsController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: GestureDetector(
                        onTap: () {
                          onTapGoogleMaps();
                        },
                        child: Container(
                            height: size.height,
                            width: size.width,
                            decoration:
                                BoxDecoration(color: ColorConstant.whiteA700),
                            child: Stack(children: [
                              Align(
                                  alignment: Alignment.center,
                                  child: Padding(
                                      padding: EdgeInsets.only(
                                          left: getHorizontalSize(30.00),
                                          top: getVerticalSize(40.00),
                                          right: getHorizontalSize(30.00),
                                          bottom: getVerticalSize(20.00)),
                                      child: Image.asset(
                                          ImageConstant.imgGooglemaps1,
                                          height: getVerticalSize(307.27),
                                          width: getHorizontalSize(300.00),
                                          fit: BoxFit.fill)))
                            ])))))));
  }

  onTapGoogleMaps() {
    Get.toNamed(AppRoutes.cutsCardScreen);
  }
}
