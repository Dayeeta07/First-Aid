class CutsCardModel {}
