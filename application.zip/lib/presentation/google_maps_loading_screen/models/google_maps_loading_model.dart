class GoogleMapsLoadingModel {}
