import '../controller/daily_cards_final_4_controller.dart';
import 'package:get/get.dart';

class DailyCardsFinal4Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DailyCardsFinal4Controller());
  }
}
