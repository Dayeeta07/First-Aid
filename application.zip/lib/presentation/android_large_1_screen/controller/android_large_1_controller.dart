import '/core/app_export.dart';
import 'package:application/presentation/android_large_1_screen/models/android_large_1_model.dart';

class AndroidLarge1Controller extends GetxController with StateMixin<dynamic> {
  Rx<AndroidLarge1Model> androidLarge1ModelObj = AndroidLarge1Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
