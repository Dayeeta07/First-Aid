import '/core/app_export.dart';
import 'package:application/presentation/symptoms_page_screen/models/symptoms_page_model.dart';

class SymptomsPageController extends GetxController with StateMixin<dynamic> {
  Rx<SymptomsPageModel> symptomsPageModelObj = SymptomsPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
