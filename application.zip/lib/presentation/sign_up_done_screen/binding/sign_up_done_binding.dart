import '../controller/sign_up_done_controller.dart';
import 'package:get/get.dart';

class SignUpDoneBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SignUpDoneController());
  }
}
