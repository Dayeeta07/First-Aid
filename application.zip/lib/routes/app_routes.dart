import 'package:application/presentation/menu_screen/menu_screen.dart';
import 'package:application/presentation/menu_screen/binding/menu_binding.dart';
import 'package:application/presentation/emergency_page_screen/emergency_page_screen.dart';
import 'package:application/presentation/emergency_page_screen/binding/emergency_page_binding.dart';
import 'package:application/presentation/symptoms_page_screen/symptoms_page_screen.dart';
import 'package:application/presentation/symptoms_page_screen/binding/symptoms_page_binding.dart';
import 'package:application/presentation/cuts_card_screen/cuts_card_screen.dart';
import 'package:application/presentation/cuts_card_screen/binding/cuts_card_binding.dart';
import 'package:application/presentation/cuts_card1_screen/cuts_card1_screen.dart';
import 'package:application/presentation/cuts_card1_screen/binding/cuts_card1_binding.dart';
import 'package:application/presentation/settings_screen/settings_screen.dart';
import 'package:application/presentation/settings_screen/binding/settings_binding.dart';
import 'package:application/presentation/settings1_screen/settings1_screen.dart';
import 'package:application/presentation/settings1_screen/binding/settings1_binding.dart';
import 'package:application/presentation/settings2_screen/settings2_screen.dart';
import 'package:application/presentation/settings2_screen/binding/settings2_binding.dart';
import 'package:application/presentation/settings_dark_screen/settings_dark_screen.dart';
import 'package:application/presentation/settings_dark_screen/binding/settings_dark_binding.dart';
import 'package:application/presentation/choosing_page_screen/choosing_page_screen.dart';
import 'package:application/presentation/choosing_page_screen/binding/choosing_page_binding.dart';
import 'package:application/presentation/logo_screen/logo_screen.dart';
import 'package:application/presentation/logo_screen/binding/logo_binding.dart';
import 'package:application/presentation/sign_up_or_login_screen/sign_up_or_login_screen.dart';
import 'package:application/presentation/sign_up_or_login_screen/binding/sign_up_or_login_binding.dart';
import 'package:application/presentation/sign_up_screen/sign_up_screen.dart';
import 'package:application/presentation/sign_up_screen/binding/sign_up_binding.dart';
import 'package:application/presentation/sign_up_done_screen/sign_up_done_screen.dart';
import 'package:application/presentation/sign_up_done_screen/binding/sign_up_done_binding.dart';
import 'package:application/presentation/loading_page_screen/loading_page_screen.dart';
import 'package:application/presentation/loading_page_screen/binding/loading_page_binding.dart';
import 'package:application/presentation/android_large_1_screen/android_large_1_screen.dart';
import 'package:application/presentation/android_large_1_screen/binding/android_large_1_binding.dart';
import 'package:application/presentation/daily_cards_final_4_screen/daily_cards_final_4_screen.dart';
import 'package:application/presentation/daily_cards_final_4_screen/binding/daily_cards_final_4_binding.dart';
import 'package:application/presentation/daily_cards_final_3_screen/daily_cards_final_3_screen.dart';
import 'package:application/presentation/daily_cards_final_3_screen/binding/daily_cards_final_3_binding.dart';
import 'package:application/presentation/daily_cards_final_2_screen/daily_cards_final_2_screen.dart';
import 'package:application/presentation/daily_cards_final_2_screen/binding/daily_cards_final_2_binding.dart';
import 'package:application/presentation/daily_cards_final_1_screen/daily_cards_final_1_screen.dart';
import 'package:application/presentation/daily_cards_final_1_screen/binding/daily_cards_final_1_binding.dart';
import 'package:application/presentation/google_maps_loading_screen/google_maps_loading_screen.dart';
import 'package:application/presentation/google_maps_loading_screen/binding/google_maps_loading_binding.dart';
import 'package:application/presentation/google_maps_screen/google_maps_screen.dart';
import 'package:application/presentation/google_maps_screen/binding/google_maps_binding.dart';
import 'package:application/presentation/app_navigation_screen/app_navigation_screen.dart';
import 'package:application/presentation/app_navigation_screen/binding/app_navigation_binding.dart';
import 'package:get/get.dart';

class AppRoutes {
  static String menuScreen = '/menu_screen';

  static String emergencyPageScreen = '/emergency_page_screen';

  static String symptomsPageScreen = '/symptoms_page_screen';

  static String cutsCardScreen = '/cuts_card_screen';

  static String cutsCard1Screen = '/cuts_card1_screen';

  static String settingsScreen = '/settings_screen';

  static String settings1Screen = '/settings1_screen';

  static String settings2Screen = '/settings2_screen';

  static String settingsDarkScreen = '/settings_dark_screen';

  static String choosingPageScreen = '/choosing_page_screen';

  static String logoScreen = '/logo_screen';

  static String signUpOrLoginScreen = '/sign_up_or_login_screen';

  static String signUpScreen = '/sign_up_screen';

  static String signUpDoneScreen = '/sign_up_done_screen';

  static String loadingPageScreen = '/loading_page_screen';

  static String androidLarge1Screen = '/android_large_1_screen';

  static String dailyCardsFinal4Screen = '/daily_cards_final_4_screen';

  static String dailyCardsFinal3Screen = '/daily_cards_final_3_screen';

  static String dailyCardsFinal2Screen = '/daily_cards_final_2_screen';

  static String dailyCardsFinal1Screen = '/daily_cards_final_1_screen';

  static String googleMapsLoadingScreen = '/google_maps_loading_screen';

  static String googleMapsScreen = '/google_maps_screen';

  static String appNavigationScreen = '/app_navigation_screen';

  static String initialRoute = '/initialRoute';

  static List<GetPage> pages = [
    GetPage(
      name: menuScreen,
      page: () => MenuScreen(),
      bindings: [
        MenuBinding(),
      ],
    ),
    GetPage(
      name: emergencyPageScreen,
      page: () => EmergencyPageScreen(),
      bindings: [
        EmergencyPageBinding(),
      ],
    ),
    GetPage(
      name: symptomsPageScreen,
      page: () => SymptomsPageScreen(),
      bindings: [
        SymptomsPageBinding(),
      ],
    ),
    GetPage(
      name: cutsCardScreen,
      page: () => CutsCardScreen(),
      bindings: [
        CutsCardBinding(),
      ],
    ),
    GetPage(
      name: cutsCard1Screen,
      page: () => CutsCard1Screen(),
      bindings: [
        CutsCard1Binding(),
      ],
    ),
    GetPage(
      name: settingsScreen,
      page: () => SettingsScreen(),
      bindings: [
        SettingsBinding(),
      ],
    ),
    GetPage(
      name: settings1Screen,
      page: () => Settings1Screen(),
      bindings: [
        Settings1Binding(),
      ],
    ),
    GetPage(
      name: settings2Screen,
      page: () => Settings2Screen(),
      bindings: [
        Settings2Binding(),
      ],
    ),
    GetPage(
      name: settingsDarkScreen,
      page: () => SettingsDarkScreen(),
      bindings: [
        SettingsDarkBinding(),
      ],
    ),
    GetPage(
      name: choosingPageScreen,
      page: () => ChoosingPageScreen(),
      bindings: [
        ChoosingPageBinding(),
      ],
    ),
    GetPage(
      name: logoScreen,
      page: () => LogoScreen(),
      bindings: [
        LogoBinding(),
      ],
    ),
    GetPage(
      name: signUpOrLoginScreen,
      page: () => SignUpOrLoginScreen(),
      bindings: [
        SignUpOrLoginBinding(),
      ],
    ),
    GetPage(
      name: signUpScreen,
      page: () => SignUpScreen(),
      bindings: [
        SignUpBinding(),
      ],
    ),
    GetPage(
      name: signUpDoneScreen,
      page: () => SignUpDoneScreen(),
      bindings: [
        SignUpDoneBinding(),
      ],
    ),
    GetPage(
      name: loadingPageScreen,
      page: () => LoadingPageScreen(),
      bindings: [
        LoadingPageBinding(),
      ],
    ),
    GetPage(
      name: androidLarge1Screen,
      page: () => AndroidLarge1Screen(),
      bindings: [
        AndroidLarge1Binding(),
      ],
    ),
    GetPage(
      name: dailyCardsFinal4Screen,
      page: () => DailyCardsFinal4Screen(),
      bindings: [
        DailyCardsFinal4Binding(),
      ],
    ),
    GetPage(
      name: dailyCardsFinal3Screen,
      page: () => DailyCardsFinal3Screen(),
      bindings: [
        DailyCardsFinal3Binding(),
      ],
    ),
    GetPage(
      name: dailyCardsFinal2Screen,
      page: () => DailyCardsFinal2Screen(),
      bindings: [
        DailyCardsFinal2Binding(),
      ],
    ),
    GetPage(
      name: dailyCardsFinal1Screen,
      page: () => DailyCardsFinal1Screen(),
      bindings: [
        DailyCardsFinal1Binding(),
      ],
    ),
    GetPage(
      name: googleMapsLoadingScreen,
      page: () => GoogleMapsLoadingScreen(),
      bindings: [
        GoogleMapsLoadingBinding(),
      ],
    ),
    GetPage(
      name: googleMapsScreen,
      page: () => GoogleMapsScreen(),
      bindings: [
        GoogleMapsBinding(),
      ],
    ),
    GetPage(
      name: appNavigationScreen,
      page: () => AppNavigationScreen(),
      bindings: [
        AppNavigationBinding(),
      ],
    ),
    GetPage(
      name: initialRoute,
      page: () => AndroidLarge1Screen(),
      bindings: [
        AndroidLarge1Binding(),
      ],
    )
  ];
}
