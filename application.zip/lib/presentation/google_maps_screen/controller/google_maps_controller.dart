import '/core/app_export.dart';
import 'package:application/presentation/google_maps_screen/models/google_maps_model.dart';

class GoogleMapsController extends GetxController with StateMixin<dynamic> {
  Rx<GoogleMapsModel> googleMapsModelObj = GoogleMapsModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
