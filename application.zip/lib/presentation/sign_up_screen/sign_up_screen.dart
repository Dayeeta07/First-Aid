import 'controller/sign_up_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class SignUpScreen extends GetWidget<SignUpController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: size.width,
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: getVerticalSize(780.00),
                                  width: getHorizontalSize(330.00),
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(15.00),
                                      top: getVerticalSize(10.00),
                                      right: getHorizontalSize(15.00),
                                      bottom: getVerticalSize(10.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red400,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))))),
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(20.00),
                                      top: getVerticalSize(15.00),
                                      right: getHorizontalSize(20.00),
                                      bottom: getVerticalSize(15.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red50,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Container(
                                                height: getVerticalSize(152.00),
                                                width:
                                                    getHorizontalSize(300.00),
                                                margin: EdgeInsets.only(
                                                    left:
                                                        getHorizontalSize(2.00),
                                                    right: getHorizontalSize(
                                                        18.00)),
                                                child: Stack(
                                                    alignment:
                                                        Alignment.topLeft,
                                                    children: [
                                                      Align(
                                                          alignment: Alignment
                                                              .bottomRight,
                                                          child: Container(
                                                              width:
                                                                  getHorizontalSize(
                                                                      284.00),
                                                              margin: EdgeInsets.only(
                                                                  left: getHorizontalSize(
                                                                      10.00),
                                                                  top: getVerticalSize(
                                                                      10.00)),
                                                              child: Text(
                                                                  "msg_we_hope_you_hav"
                                                                      .tr,
                                                                  maxLines:
                                                                      null,
                                                                  textAlign:
                                                                      TextAlign
                                                                          .center,
                                                                  style: AppStyle
                                                                      .textStyleRobotoromanextrabold30
                                                                      .copyWith(
                                                                          fontSize:
                                                                              getFontSize(30))))),
                                                      Align(
                                                          alignment:
                                                              Alignment.topLeft,
                                                          child: Padding(
                                                              padding: EdgeInsets.only(
                                                                  right:
                                                                      getHorizontalSize(
                                                                          10.00),
                                                                  bottom:
                                                                      getVerticalSize(
                                                                          10.00)),
                                                              child: Container(
                                                                  height:
                                                                      getVerticalSize(
                                                                          89.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          91.00),
                                                                  child: SvgPicture.asset(
                                                                      ImageConstant
                                                                          .imgMaskgroup11,
                                                                      fit: BoxFit
                                                                          .fill))))
                                                    ]))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(55.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .nameController,
                                                    decoration: InputDecoration(
                                                        hintText: "lbl_name".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize: getFontSize(
                                                                    15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                    getHorizontalSize(10.00)),
                                                            borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(33.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .genderController,
                                                    decoration: InputDecoration(
                                                        hintText:
                                                            "lbl_gender".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(getHorizontalSize(10.00)),
                                                            borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(33.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .dObController,
                                                    decoration: InputDecoration(
                                                        hintText:
                                                            "lbl_d_o_b".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius.circular(getHorizontalSize(10.00)),
                                                                borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(33.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .phoneController,
                                                    decoration: InputDecoration(
                                                        hintText:
                                                            "lbl_phone".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(getHorizontalSize(10.00)),
                                                            borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(33.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .emailController,
                                                    decoration: InputDecoration(
                                                        hintText:
                                                            "lbl_email".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder: OutlineInputBorder(
                                                            borderRadius:
                                                                BorderRadius.circular(getHorizontalSize(10.00)),
                                                            borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(22.00),
                                                top: getVerticalSize(33.00),
                                                right:
                                                    getHorizontalSize(18.00)),
                                            child: Container(
                                                height: getVerticalSize(40.00),
                                                width:
                                                    getHorizontalSize(280.00),
                                                child: TextFormField(
                                                    controller: controller
                                                        .passwordController,
                                                    obscureText: true,
                                                    decoration: InputDecoration(
                                                        hintText:
                                                            "lbl_password".tr,
                                                        hintStyle: AppStyle
                                                            .textStyleRobotoitalicbold151
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        15.0),
                                                                color: ColorConstant
                                                                    .redA1007f),
                                                        enabledBorder:
                                                            OutlineInputBorder(
                                                                borderRadius:
                                                                    BorderRadius.circular(getHorizontalSize(10.00)),
                                                                borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(getHorizontalSize(10.00)), borderSide: BorderSide(color: ColorConstant.red900, width: 0.6)),
                                                        filled: true,
                                                        fillColor: ColorConstant.red50,
                                                        isDense: true,
                                                        contentPadding: EdgeInsets.only(left: getHorizontalSize(23.00), top: getVerticalSize(12.29), bottom: getVerticalSize(12.29))),
                                                    style: TextStyle(color: ColorConstant.redA1007f, fontSize: getFontSize(15.0), fontFamily: 'Roboto', fontWeight: FontWeight.w700)))),
                                        Align(
                                            alignment: Alignment.center,
                                            child: Padding(
                                                padding: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        22.00),
                                                    top: getVerticalSize(31.00),
                                                    right: getHorizontalSize(
                                                        22.00)),
                                                child: GestureDetector(
                                                    onTap: () {
                                                      onTapBtnSignup();
                                                    },
                                                    child: Container(
                                                        alignment:
                                                            Alignment.center,
                                                        height: getVerticalSize(
                                                            39.23),
                                                        width: getHorizontalSize(
                                                            120.00),
                                                        decoration: BoxDecoration(
                                                            color: ColorConstant
                                                                .red400,
                                                            borderRadius: BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    60.00))),
                                                        child: Text(
                                                            "lbl_sign_up".tr,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: AppStyle
                                                                .textStyleRobotoromanextrabold16
                                                                .copyWith(fontSize: getFontSize(16))))))),
                                        Align(
                                            alignment: Alignment.center,
                                            child: Container(
                                                margin: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        22.00),
                                                    top: getVerticalSize(22.77),
                                                    right: getHorizontalSize(
                                                        22.00),
                                                    bottom:
                                                        getVerticalSize(47.00)),
                                                child: RichText(
                                                    text: TextSpan(children: [
                                                      TextSpan(
                                                          text: "lbl_faq".tr,
                                                          style: TextStyle(
                                                              color:
                                                                  ColorConstant
                                                                      .redA100,
                                                              fontSize:
                                                                  getFontSize(
                                                                      15),
                                                              fontFamily:
                                                                  'Roboto',
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w800)),
                                                      TextSpan(
                                                          text: "lbl_s".tr,
                                                          style: TextStyle(
                                                              color:
                                                                  ColorConstant
                                                                      .redA100,
                                                              fontSize:
                                                                  getFontSize(
                                                                      15),
                                                              fontFamily:
                                                                  'Roboto',
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w800)),
                                                      TextSpan(
                                                          text: "lbl2".tr,
                                                          style: TextStyle(
                                                              color:
                                                                  ColorConstant
                                                                      .redA100,
                                                              fontSize:
                                                                  getFontSize(
                                                                      15),
                                                              fontFamily:
                                                                  'Roboto',
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w800))
                                                    ]),
                                                    textAlign:
                                                        TextAlign.center)))
                                      ])))
                        ]))))));
  }

  onTapBtnSignup() {
    Get.toNamed(AppRoutes.signUpDoneScreen);
  }
}
