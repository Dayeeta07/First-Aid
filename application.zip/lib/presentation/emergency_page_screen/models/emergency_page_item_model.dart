class EmergencyPageItemModel {}
