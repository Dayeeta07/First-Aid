import 'controller/loading_page_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class LoadingPageScreen extends GetWidget<LoadingPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.redA1003f,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: GestureDetector(
                        onTap: () {
                          onTapTW();
                        },
                        child: Container(
                            decoration:
                                BoxDecoration(color: ColorConstant.redA1003f),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [])))))));
  }

  onTapTW() {
    Get.toNamed(AppRoutes.choosingPageScreen);
  }
}
