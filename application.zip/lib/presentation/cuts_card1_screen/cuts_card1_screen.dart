import 'controller/cuts_card1_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CutsCard1Screen extends GetWidget<CutsCard1Controller> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                      padding: EdgeInsets.only(
                                          bottom: getVerticalSize(19.00)),
                                      child: Column(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          children: [
                                            Align(
                                                alignment: Alignment.centerLeft,
                                                child: Container(
                                                    height:
                                                        getVerticalSize(132.00),
                                                    width: size.width,
                                                    child: Stack(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        children: [
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Container(
                                                                  height:
                                                                      getVerticalSize(
                                                                          132.00),
                                                                  width:
                                                                      getHorizontalSize(
                                                                          360.00),
                                                                  child: SvgPicture.asset(
                                                                      ImageConstant
                                                                          .imgMaskgroup5,
                                                                      fit: BoxFit
                                                                          .fill))),
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Container(
                                                                  decoration: BoxDecoration(
                                                                      color: ColorConstant
                                                                          .red400,
                                                                      borderRadius: BorderRadius.only(
                                                                          topLeft: Radius.circular(getHorizontalSize(
                                                                              42.00)),
                                                                          topRight: Radius.circular(getHorizontalSize(
                                                                              42.00)),
                                                                          bottomLeft: Radius.circular(getHorizontalSize(
                                                                              0.00)),
                                                                          bottomRight: Radius.circular(getHorizontalSize(
                                                                              0.00)))),
                                                                  child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .start,
                                                                      mainAxisSize:
                                                                          MainAxisSize
                                                                              .max,
                                                                      children: [
                                                                        Padding(
                                                                            padding: EdgeInsets.only(
                                                                                left: getHorizontalSize(14.00),
                                                                                top: getVerticalSize(20.00),
                                                                                bottom: getVerticalSize(18.00)),
                                                                            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                              Align(
                                                                                  alignment: Alignment.centerLeft,
                                                                                  child: Row(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.max, children: [
                                                                                    Container(
                                                                                        height: getSize(53.00),
                                                                                        width: getSize(53.00),
                                                                                        margin: EdgeInsets.only(bottom: getVerticalSize(12.00)),
                                                                                        child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                          Align(alignment: Alignment.center, child: Container(height: getSize(37.00), width: getSize(37.00), margin: EdgeInsets.only(left: getHorizontalSize(9.00), top: getVerticalSize(7.00), right: getHorizontalSize(7.00), bottom: getVerticalSize(9.00)), decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))))),
                                                                                          Align(
                                                                                              alignment: Alignment.centerLeft,
                                                                                              child: Container(
                                                                                                  height: getSize(53.00),
                                                                                                  width: getSize(53.00),
                                                                                                  child: Stack(alignment: Alignment.center, children: [
                                                                                                    Align(
                                                                                                        alignment: Alignment.centerLeft,
                                                                                                        child: GestureDetector(
                                                                                                            onTap: () {
                                                                                                              onTapImgMenuPNG1();
                                                                                                            },
                                                                                                            child: Image.asset(ImageConstant.imgMenupng1, height: getSize(53.00), width: getSize(53.00), fit: BoxFit.fill))),
                                                                                                    Align(alignment: Alignment.center, child: Container(height: getVerticalSize(41.00), width: getHorizontalSize(45.00), margin: EdgeInsets.only(left: getHorizontalSize(5.00), top: getVerticalSize(5.00), right: getHorizontalSize(3.00), bottom: getVerticalSize(7.00)), decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00)))))
                                                                                                  ])))
                                                                                        ])),
                                                                                    Padding(padding: EdgeInsets.only(left: getHorizontalSize(68.00), top: getVerticalSize(27.00), right: getHorizontalSize(66.00)), child: Text("lbl_cuts2".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanblack32.copyWith(fontSize: getFontSize(32))))
                                                                                  ])),
                                                                              Padding(padding: EdgeInsets.only(left: getHorizontalSize(10.00), top: getVerticalSize(10.00)), child: Text("msg_by".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanblack16.copyWith(fontSize: getFontSize(16))))
                                                                            ])),
                                                                        Container(
                                                                            height: getVerticalSize(
                                                                                65.00),
                                                                            width: getHorizontalSize(
                                                                                63.00),
                                                                            margin: EdgeInsets.only(
                                                                                left: getHorizontalSize(1.00),
                                                                                top: getVerticalSize(8.00),
                                                                                right: getHorizontalSize(12.00),
                                                                                bottom: getVerticalSize(59.00)),
                                                                            child: Stack(alignment: Alignment.centerLeft, children: [
                                                                              Align(alignment: Alignment.center, child: Container(height: getSize(37.00), width: getSize(37.00), margin: EdgeInsets.only(left: getHorizontalSize(13.00), top: getVerticalSize(14.00), right: getHorizontalSize(13.00), bottom: getVerticalSize(14.00)), decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))))),
                                                                              Align(
                                                                                  alignment: Alignment.centerLeft,
                                                                                  child: GestureDetector(
                                                                                      onTap: () {
                                                                                        onTapImgMaskgroup();
                                                                                      },
                                                                                      child: Container(height: getVerticalSize(65.00), width: getHorizontalSize(63.00), child: SvgPicture.asset(ImageConstant.imgMaskgroup6, fit: BoxFit.fill))))
                                                                            ]))
                                                                      ])))
                                                        ]))),
                                            Container(
                                                height: getVerticalSize(488.00),
                                                width:
                                                    getHorizontalSize(334.00),
                                                margin: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        14.00),
                                                    top: getVerticalSize(20.00),
                                                    right: getHorizontalSize(
                                                        12.00)),
                                                child: Stack(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    children: [
                                                      Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child: Container(
                                                              margin: EdgeInsets.only(
                                                                  top: getVerticalSize(
                                                                      8.00)),
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              10.00)),
                                                                  gradient: LinearGradient(
                                                                      begin:
                                                                          Alignment(0.06000000963314096, 0.04222222262683073),
                                                                      end: Alignment(1.0000000280141834, 1.000000028544003),
                                                                      colors: [
                                                                        ColorConstant
                                                                            .red400,
                                                                        ColorConstant
                                                                            .redA10080
                                                                      ])),
                                                              child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Align(
                                                                        alignment:
                                                                            Alignment
                                                                                .centerLeft,
                                                                        child: Container(
                                                                            width: getHorizontalSize(
                                                                                305.00),
                                                                            margin: EdgeInsets.only(
                                                                                left: getHorizontalSize(16.00),
                                                                                top: getVerticalSize(7.00),
                                                                                right: getHorizontalSize(13.00),
                                                                                bottom: getVerticalSize(6.00)),
                                                                            child: Text("msg_lorem_ipsum_dol".tr, maxLines: null, textAlign: TextAlign.left, style: AppStyle.textStyleInterregular24.copyWith(fontSize: getFontSize(24)))))
                                                                  ]))),
                                                      Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child: Container(
                                                              height:
                                                                  getVerticalSize(
                                                                      488.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      334.00),
                                                              decoration: BoxDecoration(
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              10.00)),
                                                                  gradient: LinearGradient(
                                                                      begin: Alignment(
                                                                          0.5000000158616336,
                                                                          1.034523800946595),
                                                                      end: Alignment(0.4999999942191477, -3.5854943458701882e-9),
                                                                      colors: [
                                                                        ColorConstant
                                                                            .deepOrange100,
                                                                        ColorConstant
                                                                            .deepOrange10000
                                                                      ]))))
                                                    ])),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        14.00),
                                                    top: getVerticalSize(64.00),
                                                    right: getHorizontalSize(
                                                        14.00)),
                                                child: Container(
                                                    alignment: Alignment.center,
                                                    height:
                                                        getVerticalSize(50.00),
                                                    width: getHorizontalSize(
                                                        300.00),
                                                    decoration: AppDecoration
                                                        .textStyleRobotoromanblack201,
                                                    child: Text("msg".tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .textStyleRobotoromanblack201
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        20))))),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        14.00),
                                                    top: getVerticalSize(8.00),
                                                    right: getHorizontalSize(
                                                        14.00)),
                                                child: Text(
                                                    "msg_nearest_healthc"
                                                        .tr
                                                        .toUpperCase(),
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    textAlign: TextAlign.center,
                                                    style: AppStyle
                                                        .textStyleRobotoromanblack161
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    16))))
                                          ])))
                            ]))))));
  }

  onTapImgMenuPNG1() {
    Get.toNamed(AppRoutes.menuScreen);
  }

  onTapImgMaskgroup() {
    Get.toNamed(AppRoutes.emergencyPageScreen);
  }
}
