import 'controller/android_large_1_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class AndroidLarge1Screen extends GetWidget<AndroidLarge1Controller> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: size.width,
                        decoration:
                            BoxDecoration(color: ColorConstant.whiteA700),
                        child:
                            Stack(alignment: Alignment.centerLeft, children: [
                          Align(
                              alignment: Alignment.bottomRight,
                              child: GestureDetector(
                                  onTap: () {
                                    onTapEllipse17();
                                  },
                                  child: Container(
                                      height: getSize(64.00),
                                      width: getSize(64.00),
                                      margin: EdgeInsets.only(
                                          left: getHorizontalSize(106.00),
                                          top: getVerticalSize(302.00),
                                          right: getHorizontalSize(106.00),
                                          bottom: getVerticalSize(302.00)),
                                      decoration: BoxDecoration(
                                          color: ColorConstant.whiteA700,
                                          borderRadius: BorderRadius.circular(
                                              getHorizontalSize(32.00)))))),
                          Align(
                              alignment: Alignment.centerLeft,
                              child: Image.asset(
                                  ImageConstant.imgUntitled342022,
                                  height: getVerticalSize(800.00),
                                  width: getHorizontalSize(360.00),
                                  fit: BoxFit.fill))
                        ]))))));
  }

  onTapEllipse17() {
    Get.toNamed(AppRoutes.logoScreen);
  }
}
