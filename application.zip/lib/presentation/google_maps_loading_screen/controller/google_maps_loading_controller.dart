import '/core/app_export.dart';
import 'package:application/presentation/google_maps_loading_screen/models/google_maps_loading_model.dart';

class GoogleMapsLoadingController extends GetxController
    with StateMixin<dynamic> {
  Rx<GoogleMapsLoadingModel> googleMapsLoadingModelObj =
      GoogleMapsLoadingModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
