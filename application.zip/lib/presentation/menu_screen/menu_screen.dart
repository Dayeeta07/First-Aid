import 'controller/menu_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class MenuScreen extends GetWidget<MenuController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                      Align(
                          alignment: Alignment.centerLeft,
                          child: Container(
                              height: size.height,
                              width: getHorizontalSize(340.00),
                              child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    Align(
                                        alignment: Alignment.centerLeft,
                                        child: Container(
                                            height: size.height,
                                            width: getHorizontalSize(340.00),
                                            child: Stack(
                                                alignment: Alignment.topRight,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          margin: EdgeInsets.only(
                                                              right:
                                                                  getHorizontalSize(
                                                                      10.00)),
                                                          decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.only(
                                                                  topLeft: Radius.circular(
                                                                      getHorizontalSize(
                                                                          42.00)),
                                                                  topRight: Radius.circular(
                                                                      getHorizontalSize(
                                                                          15.00)),
                                                                  bottomLeft: Radius
                                                                      .circular(
                                                                          getHorizontalSize(42.00)),
                                                                  bottomRight: Radius.circular(getHorizontalSize(15.00))),
                                                              gradient: LinearGradient(begin: Alignment(0.9480519149677635, 0.9999999393963661), end: Alignment(-4.806058928608081e-8, 0.013749903418203369), colors: [ColorConstant.red400Cc, ColorConstant.redA100Cc, ColorConstant.deepOrange100Cc])),
                                                          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child:
                                                                    Container(
                                                                        width: getHorizontalSize(
                                                                            115.00),
                                                                        margin: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                53.00),
                                                                            top: getVerticalSize(
                                                                                58.00),
                                                                            right: getHorizontalSize(
                                                                                53.00)),
                                                                        decoration: BoxDecoration(
                                                                            borderRadius: BorderRadius.circular(getHorizontalSize(
                                                                                57.50)),
                                                                            gradient:
                                                                                LinearGradient(begin: Alignment(0.5000000242676068, 0.5000000255167044), end: Alignment(0.5000000628751633, 1.295454618384011), colors: [
                                                                              ColorConstant.whiteA700,
                                                                              ColorConstant.gray40000
                                                                            ])),
                                                                        child: Column(
                                                                            mainAxisSize:
                                                                                MainAxisSize.min,
                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            children: [
                                                                              Align(alignment: Alignment.centerLeft, child: ClipRRect(borderRadius: BorderRadius.circular(getHorizontalSize(139.50)), child: Image.asset(ImageConstant.imgPngtreecartoon, height: getSize(115.00), width: getSize(115.00), fit: BoxFit.fill)))
                                                                            ]))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child: Padding(
                                                                    padding: EdgeInsets.only(
                                                                        left: getHorizontalSize(
                                                                            53.00),
                                                                        top: getVerticalSize(
                                                                            35.00),
                                                                        right: getHorizontalSize(
                                                                            53.00)),
                                                                    child: Container(
                                                                        alignment:
                                                                            Alignment
                                                                                .center,
                                                                        height: getVerticalSize(
                                                                            30.00),
                                                                        width: getHorizontalSize(
                                                                            175.00),
                                                                        decoration:
                                                                            AppDecoration
                                                                                .textStyleRobotoromansemibold20,
                                                                        child: Text(
                                                                            "lbl_dayeeta_c".tr,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromansemibold20.copyWith(fontSize: getFontSize(20)))))),
                                                            Container(
                                                                width: getHorizontalSize(
                                                                    252.00),
                                                                margin: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        2.00),
                                                                    top: getVerticalSize(
                                                                        77.00),
                                                                    right: getHorizontalSize(
                                                                        10.00)),
                                                                padding: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        15.00),
                                                                    top: getVerticalSize(
                                                                        18.00),
                                                                    right: getHorizontalSize(
                                                                        11.00),
                                                                    bottom: getVerticalSize(
                                                                        18.00)),
                                                                decoration:
                                                                    AppDecoration
                                                                        .textStyleRobotoromansemibold26,
                                                                child: Text("msg_nearest_healthc".tr,
                                                                    maxLines:
                                                                        null,
                                                                    textAlign: TextAlign
                                                                        .center,
                                                                    style: AppStyle
                                                                        .textStyleRobotoromansemibold26
                                                                        .copyWith(fontSize: getFontSize(26)))),
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        2.00),
                                                                    top: getVerticalSize(
                                                                        32.00),
                                                                    right: getHorizontalSize(
                                                                        10.00)),
                                                                child: Container(
                                                                    alignment: Alignment
                                                                        .center,
                                                                    height: getVerticalSize(
                                                                        66.00),
                                                                    width: getHorizontalSize(
                                                                        252.00),
                                                                    decoration:
                                                                        AppDecoration
                                                                            .textStyleRobotoromansemibold26,
                                                                    child: Text(
                                                                        "msg_book_appointmen"
                                                                            .tr,
                                                                        textAlign: TextAlign
                                                                            .center,
                                                                        style: AppStyle
                                                                            .textStyleRobotoromansemibold26
                                                                            .copyWith(fontSize: getFontSize(26))))),
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        2.00),
                                                                    top: getVerticalSize(
                                                                        29.00),
                                                                    right: getHorizontalSize(
                                                                        10.00)),
                                                                child: Container(
                                                                    alignment: Alignment
                                                                        .center,
                                                                    height: getVerticalSize(
                                                                        66.00),
                                                                    width: getHorizontalSize(
                                                                        252.00),
                                                                    decoration:
                                                                        AppDecoration
                                                                            .textStyleRobotoromansemibold26,
                                                                    child: Text(
                                                                        "lbl_guide"
                                                                            .tr,
                                                                        textAlign: TextAlign
                                                                            .center,
                                                                        style: AppStyle
                                                                            .textStyleRobotoromansemibold26
                                                                            .copyWith(fontSize: getFontSize(26))))),
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        2.00),
                                                                    top: getVerticalSize(
                                                                        35.00),
                                                                    right: getHorizontalSize(
                                                                        10.00)),
                                                                child:
                                                                    GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          onTapBtnExitapp();
                                                                        },
                                                                        child: Container(
                                                                            alignment: Alignment
                                                                                .center,
                                                                            height: getVerticalSize(
                                                                                66.00),
                                                                            width: getHorizontalSize(
                                                                                252.00),
                                                                            decoration: AppDecoration
                                                                                .textStyleRobotoromansemibold26,
                                                                            child: Text("lbl_exit_app".tr,
                                                                                textAlign: TextAlign.center,
                                                                                style: AppStyle.textStyleRobotoromansemibold26.copyWith(fontSize: getFontSize(26)))))),
                                                            Align(
                                                                alignment:
                                                                    Alignment
                                                                        .center,
                                                                child: Padding(
                                                                    padding: EdgeInsets.only(
                                                                        left: getHorizontalSize(
                                                                            53.00),
                                                                        top: getVerticalSize(
                                                                            64.00),
                                                                        right: getHorizontalSize(
                                                                            53.00),
                                                                        bottom: getVerticalSize(
                                                                            20.00)),
                                                                    child: Text(
                                                                        "msg_about_us_term"
                                                                            .tr,
                                                                        overflow:
                                                                            TextOverflow
                                                                                .ellipsis,
                                                                        textAlign:
                                                                            TextAlign
                                                                                .left,
                                                                        style: AppStyle
                                                                            .textStyleRobotoromansemibold14
                                                                            .copyWith(fontSize: getFontSize(14)))))
                                                          ]))),
                                                  Align(
                                                      alignment:
                                                          Alignment.topRight,
                                                      child: Padding(
                                                          padding: EdgeInsets.only(
                                                              left: getHorizontalSize(
                                                                  10.00),
                                                              top: getVerticalSize(
                                                                  11.00),
                                                              bottom:
                                                                  getVerticalSize(
                                                                      11.00)),
                                                          child: Container(
                                                              height:
                                                                  getVerticalSize(
                                                                      65.00),
                                                              width:
                                                                  getHorizontalSize(
                                                                      63.00),
                                                              child: SvgPicture.asset(
                                                                  ImageConstant
                                                                      .imgMaskgroup,
                                                                  fit: BoxFit
                                                                      .fill))))
                                                ]))),
                                    Align(
                                        alignment: Alignment.topRight,
                                        child: Container(
                                            height: getSize(37.00),
                                            width: getSize(37.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(13.00),
                                                top: getVerticalSize(25.00),
                                                right: getHorizontalSize(13.00),
                                                bottom: getVerticalSize(25.00)),
                                            decoration: BoxDecoration(
                                                color: ColorConstant.whiteA700,
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        getHorizontalSize(
                                                            18.50)))))
                                  ])))
                    ])))));
  }

  onTapBtnExitapp() {
    Get.toNamed(AppRoutes.androidLarge1Screen);
  }
}
