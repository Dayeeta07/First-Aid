import 'package:flutter/material.dart';
import 'package:application/core/app_export.dart';

class AppDecoration {
  static BoxDecoration get groupStyle1 => BoxDecoration();
  static BoxDecoration get textStyleRobotoromansemibold26 => BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(
            getHorizontalSize(
              0.00,
            ),
          ),
          topRight: Radius.circular(
            getHorizontalSize(
              15.00,
            ),
          ),
          bottomLeft: Radius.circular(
            getHorizontalSize(
              0.00,
            ),
          ),
          bottomRight: Radius.circular(
            getHorizontalSize(
              15.00,
            ),
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5000000242676068,
            0.5000000255167044,
          ),
          end: Alignment(
            0.5000000628751633,
            1.295454618384011,
          ),
          colors: [
            ColorConstant.whiteA700,
            ColorConstant.gray40000,
          ],
        ),
      );
  static BoxDecoration get groupStyledeepOrange100cornerRadius => BoxDecoration(
        color: ColorConstant.deepOrange100,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            25.00,
          ),
        ),
      );
  static BoxDecoration get textStyleRobotoromansemibold20 => BoxDecoration(
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            5.00,
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5000000242676068,
            0.5000000255167044,
          ),
          end: Alignment(
            0.5000000628751633,
            1.295454618384011,
          ),
          colors: [
            ColorConstant.whiteA700,
            ColorConstant.gray40000,
          ],
        ),
      );
  static BoxDecoration get groupStylered400cornerRadius => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(
            getHorizontalSize(
              42.00,
            ),
          ),
          topRight: Radius.circular(
            getHorizontalSize(
              42.00,
            ),
          ),
          bottomLeft: Radius.circular(
            getHorizontalSize(
              0.00,
            ),
          ),
          bottomRight: Radius.circular(
            getHorizontalSize(
              0.00,
            ),
          ),
        ),
      );
  static BoxDecoration get textStyleRobotoromanblack201 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        ),
      );
  static BoxDecoration get groupStylecornerRadius => BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(
            getHorizontalSize(
              42.00,
            ),
          ),
          topRight: Radius.circular(
            getHorizontalSize(
              15.00,
            ),
          ),
          bottomLeft: Radius.circular(
            getHorizontalSize(
              42.00,
            ),
          ),
          bottomRight: Radius.circular(
            getHorizontalSize(
              15.00,
            ),
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.9480519149677635,
            0.9999999393963661,
          ),
          end: Alignment(
            -4.806058928608081e-8,
            0.013749903418203369,
          ),
          colors: [
            ColorConstant.red400Cc,
            ColorConstant.redA100Cc,
            ColorConstant.deepOrange100Cc,
          ],
        ),
      );
  static BoxDecoration get groupStylered50cornerRadius => BoxDecoration(
        color: ColorConstant.red50,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            42.00,
          ),
        ),
      );
  static BoxDecoration get textStyleRobotoromansemibold241 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            22.00,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black90040,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      );
  static BoxDecoration get groupStylered2 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            42.00,
          ),
        ),
      );
  static BoxDecoration get groupStylered1 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        ),
      );
  static BoxDecoration get groupStyleredA100cornerRadius => BoxDecoration(
        color: ColorConstant.redA100,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            22.00,
          ),
        ),
      );
  static BoxDecoration get groupStylewhiteA700 => BoxDecoration(
        color: ColorConstant.whiteA700,
      );
  static BoxDecoration get groupStylecornerRadius3 => BoxDecoration(
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.06000000963314096,
            0.04222222262683073,
          ),
          end: Alignment(
            1.0000000280141834,
            1.000000028544003,
          ),
          colors: [
            ColorConstant.red400,
            ColorConstant.redA10080,
          ],
        ),
      );
  static BoxDecoration get groupStylecornerRadius2 => BoxDecoration(
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5,
            -3.0616171314629196e-17,
          ),
          end: Alignment(
            0.5,
            0.9999999999999999,
          ),
          colors: [
            ColorConstant.deepOrange100,
            ColorConstant.deepOrange10000,
            ColorConstant.deepOrange100,
          ],
        ),
      );
  static BoxDecoration get groupStylecornerRadius1 => BoxDecoration(
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            57.50,
          ),
        ),
        gradient: LinearGradient(
          begin: Alignment(
            0.5000000242676068,
            0.5000000255167044,
          ),
          end: Alignment(
            0.5000000628751633,
            1.295454618384011,
          ),
          colors: [
            ColorConstant.whiteA700,
            ColorConstant.gray40000,
          ],
        ),
      );
  static BoxDecoration get groupStylebluegray900cornerRadius => BoxDecoration(
        color: ColorConstant.bluegray900,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            42.00,
          ),
        ),
      );
  static BoxDecoration get textStyleRobotoromanextrabold351 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            60.00,
          ),
        ),
      );
  static BoxDecoration get groupStylewhiteA700cornerRadius => BoxDecoration(
        color: ColorConstant.whiteA700,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            18.50,
          ),
        ),
      );
  static BoxDecoration get textStyleRobotoromansemibold361 => BoxDecoration(
        color: ColorConstant.red400,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            10.00,
          ),
        ),
      );
  static BoxDecoration get groupStylered50 => BoxDecoration(
        color: ColorConstant.red50,
      );
  static BoxDecoration get groupStylered500cornerRadius => BoxDecoration(
        color: ColorConstant.red500,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            45.00,
          ),
        ),
      );
  static BoxDecoration get groupStylered900cornerRadius => BoxDecoration(
        color: ColorConstant.red900,
        borderRadius: BorderRadius.circular(
          getHorizontalSize(
            26.00,
          ),
        ),
      );
}
