import '/core/app_export.dart';
import 'package:application/presentation/daily_cards_final_1_screen/models/daily_cards_final_1_model.dart';

class DailyCardsFinal1Controller extends GetxController
    with StateMixin<dynamic> {
  Rx<DailyCardsFinal1Model> dailyCardsFinal1ModelObj =
      DailyCardsFinal1Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
