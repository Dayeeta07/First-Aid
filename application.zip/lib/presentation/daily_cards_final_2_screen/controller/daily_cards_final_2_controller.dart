import '/core/app_export.dart';
import 'package:application/presentation/daily_cards_final_2_screen/models/daily_cards_final_2_model.dart';

class DailyCardsFinal2Controller extends GetxController
    with StateMixin<dynamic> {
  Rx<DailyCardsFinal2Model> dailyCardsFinal2ModelObj =
      DailyCardsFinal2Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
