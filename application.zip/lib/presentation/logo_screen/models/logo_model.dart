class LogoModel {}
