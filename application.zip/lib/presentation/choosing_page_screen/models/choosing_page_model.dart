class ChoosingPageModel {}
