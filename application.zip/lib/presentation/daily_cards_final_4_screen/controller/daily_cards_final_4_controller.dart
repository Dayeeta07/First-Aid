import '/core/app_export.dart';
import 'package:application/presentation/daily_cards_final_4_screen/models/daily_cards_final_4_model.dart';

class DailyCardsFinal4Controller extends GetxController
    with StateMixin<dynamic> {
  Rx<DailyCardsFinal4Model> dailyCardsFinal4ModelObj =
      DailyCardsFinal4Model().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
