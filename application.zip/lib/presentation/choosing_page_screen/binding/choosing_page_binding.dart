import '../controller/choosing_page_controller.dart';
import 'package:get/get.dart';

class ChoosingPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ChoosingPageController());
  }
}
