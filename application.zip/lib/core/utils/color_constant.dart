import 'dart:ui';
import 'package:flutter/material.dart';

class ColorConstant {
  static Color red40080 = fromHex('#80f06161');

  static Color red900 = fromHex('#8a0000');

  static Color deepOrange10000 = fromHex('#00ffbaba');

  static Color red500 = fromHex('#ff4f36');

  static Color red400 = fromHex('#f06161');

  static Color red50 = fromHex('#fcf0f0');

  static Color redA100Bf = fromHex('#bfff8082');

  static Color black900 = fromHex('#000000');

  static Color black90040 = fromHex('#40000000');

  static Color redA400 = fromHex('#ff2626');

  static Color deepOrange200 = fromHex('#ffbf9c');

  static Color redA1007f = fromHex('#7fff8082');

  static Color deepOrange100 = fromHex('#ffbaba');

  static Color redA1003f = fromHex('#3fff8082');

  static Color red900Bf = fromHex('#bf8a0000');

  static Color redA100 = fromHex('#ff8082');

  static Color deepOrange100Cc = fromHex('#ccffbaba');

  static Color red400Cc = fromHex('#ccf06161');

  static Color redA100Cc = fromHex('#ccff8082');

  static Color bluegray900 = fromHex('#2b2b2b');

  static Color orange50 = fromHex('#fffad6');

  static Color redA10080 = fromHex('#80ff8082');

  static Color bluegray400 = fromHex('#888888');

  static Color gray40000 = fromHex('#00c4c4c4');

  static Color redA100E5 = fromHex('#e5ff8082');

  static Color whiteA700 = fromHex('#ffffff');

  static Color fromHex(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
