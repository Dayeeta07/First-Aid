import '../controller/symptoms_page_controller.dart';
import 'package:get/get.dart';

class SymptomsPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SymptomsPageController());
  }
}
