import '/core/app_export.dart';
import 'package:application/presentation/emergency_page_screen/models/emergency_page_model.dart';

class EmergencyPageController extends GetxController with StateMixin<dynamic> {
  Rx<EmergencyPageModel> emergencyPageModelObj = EmergencyPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
