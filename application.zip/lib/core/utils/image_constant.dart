class ImageConstant {
  static String imgMicrophonepng1 = 'assets/images/img_microphonepng1.png';

  static String imgMaskgroup10 = 'assets/images/img_maskgroup_10.svg';

  static String imgUntitled212022 = 'assets/images/img_untitled212022.png';

  static String imgReturnpng5 = 'assets/images/img_returnpng5.png';

  static String imgRectangle217 = 'assets/images/img_rectangle21_7.svg';

  static String imgMaskgroup6 = 'assets/images/img_maskgroup_6.svg';

  static String imgMaskgroup2 = 'assets/images/img_maskgroup_2.svg';

  static String imgMaskgroup5 = 'assets/images/img_maskgroup_5.svg';

  static String imgMaskgroup9 = 'assets/images/img_maskgroup_9.svg';

  static String imgMaskgroup7 = 'assets/images/img_maskgroup_7.svg';

  static String imgUnion = 'assets/images/img_union.svg';

  static String imgRectangle212 = 'assets/images/img_rectangle21_2.svg';

  static String imgRectangle215 = 'assets/images/img_rectangle21_5.svg';

  static String imgMaskgroup8 = 'assets/images/img_maskgroup_8.svg';

  static String imgRectangle214 = 'assets/images/img_rectangle21_4.svg';

  static String imgMaskgroup1 = 'assets/images/img_maskgroup_1.svg';

  static String imgUntitled342022 = 'assets/images/img_untitled342022.png';

  static String imgGooglemaps1 = 'assets/images/img_googlemaps1.png';

  static String imgMaskgroup14 = 'assets/images/img_maskgroup_14.svg';

  static String imgMaskgroup4 = 'assets/images/img_maskgroup_4.svg';

  static String imgTw = 'assets/images/img_tw.svg';

  static String imgGroup4 = 'assets/images/img_group4.png';

  static String imgMaskgroup15 = 'assets/images/img_maskgroup_15.svg';

  static String imgEllipse11 = 'assets/images/img_ellipse11.png';

  static String imgEllipse14 = 'assets/images/img_ellipse14.png';

  static String imgReturnpng2 = 'assets/images/img_returnpng2.png';

  static String imgFrame16 = 'assets/images/img_frame16.svg';

  static String imgRectangle216 = 'assets/images/img_rectangle21_6.svg';

  static String imgPngtreecartoon = 'assets/images/img_pngtreecartoon.png';

  static String imgRectangle211 = 'assets/images/img_rectangle21_1.svg';

  static String imgMaskgroup16 = 'assets/images/img_maskgroup_16.svg';

  static String imgMaskgroup = 'assets/images/img_maskgroup.svg';

  static String imgEllipse13 = 'assets/images/img_ellipse13.png';

  static String imgMaskgroup11 = 'assets/images/img_maskgroup_11.svg';

  static String imgPolygon1 = 'assets/images/img_polygon1.png';

  static String imgSettingpng1 = 'assets/images/img_settingpng1.png';

  static String imgMaskgroup13 = 'assets/images/img_maskgroup_13.svg';

  static String imgMaskgroup3 = 'assets/images/img_maskgroup_3.svg';

  static String imgMaskgroup12 = 'assets/images/img_maskgroup_12.svg';

  static String imgUntitled392022 = 'assets/images/img_untitled392022.png';

  static String imgRectangle213 = 'assets/images/img_rectangle21_3.svg';

  static String imgMenupng1 = 'assets/images/img_menupng1.png';

  static String imgRectangle21 = 'assets/images/img_rectangle21.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
