import 'package:flutter/material.dart';
import 'package:application/core/app_export.dart';

class AppStyle {
  static TextStyle textStyleRobotoromanregular241 =
      textStyleRobotoromanregular24.copyWith(
    color: ColorConstant.redA400,
  );

  static TextStyle textStyleregular20 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      20,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleRobotoromansemibold26 =
      textStyleRobotoromansemibold20.copyWith(
    fontSize: getFontSize(
      26,
    ),
  );

  static TextStyle textStyleRobotoromansemibold24 =
      textStyleRobotoromansemibold201.copyWith(
    fontSize: getFontSize(
      24,
    ),
  );

  static TextStyle textStyleRobotoromanblack32 =
      textStyleRobotoromanblack16.copyWith(
    fontSize: getFontSize(
      32,
    ),
  );

  static TextStyle textStyleRobotoromanextrabold35 =
      textStyleRobotoromanextrabold26.copyWith(
    fontSize: getFontSize(
      35,
    ),
  );

  static TextStyle textStyleRobotoromansemibold20 =
      textStyleRobotoromanblack20.copyWith(
    fontWeight: FontWeight.w600,
  );

  static TextStyle textStyleRobotoromanblack201 =
      textStyleRobotoromanblack20.copyWith(
    color: ColorConstant.orange50,
  );

  static TextStyle textStyleRobotoromanextrabold16 =
      textStyleRobotoromanextrabold351.copyWith(
    color: ColorConstant.deepOrange100,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w800,
  );

  static TextStyle textStyleRobotoromanextrabold36 =
      textStyleRobotoromanextrabold26.copyWith(
    fontSize: getFontSize(
      36,
    ),
  );

  static TextStyle textStyleRobotoromanextrabold15 =
      textStyleRobotoromanextrabold30.copyWith(
    fontSize: getFontSize(
      15,
    ),
  );

  static TextStyle textStyleRobotoitalicbold15 =
      textStyleRobotoitalicbold151.copyWith(
    color: ColorConstant.redA100,
  );

  static TextStyle textStyleRobotoromanblack16 =
      textStyleRobotoromanblack161.copyWith(
    color: ColorConstant.orange50,
  );

  static TextStyle textStyleRobotoromanblack161 =
      textStyleRobotoromanblack20.copyWith(
    fontSize: getFontSize(
      16,
    ),
  );

  static TextStyle textStyleInterregular24 = textStyleInterextrabold32.copyWith(
    fontSize: getFontSize(
      24,
    ),
  );

  static TextStyle textStyleRobotoromansemibold241 =
      textStyleRobotoromansemibold24.copyWith(
    color: ColorConstant.orange50,
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle textStyleRobotoromansemibold201 = TextStyle(
    color: ColorConstant.orange50,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle textStyleRobotoromanregular16 = TextStyle(
    color: ColorConstant.redA100,
    fontSize: getFontSize(
      16,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleRobotoromansemibold14 = TextStyle(
    color: ColorConstant.deepOrange100,
    fontSize: getFontSize(
      14,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle textStyleRobotoromansemibold36 = TextStyle(
    color: ColorConstant.whiteA700,
    fontSize: getFontSize(
      36,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w600,
  );

  static TextStyle textStyleRobotoromanextrabold351 =
      textStyleRobotoromanextrabold25.copyWith(
    fontSize: getFontSize(
      35,
    ),
  );

  static TextStyle textStyleregular16 = TextStyle(
    color: ColorConstant.bluegray400,
    fontSize: getFontSize(
      16,
    ),
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleRobotoromanblack20 = TextStyle(
    color: ColorConstant.red900,
    fontSize: getFontSize(
      20,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w900,
  );

  static TextStyle textStyleRobotoromanextrabold25 = TextStyle(
    color: ColorConstant.deepOrange100,
    fontSize: getFontSize(
      25,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w800,
  );

  static TextStyle textStyleRobotoromanextrabold26 = TextStyle(
    color: ColorConstant.red400,
    fontSize: getFontSize(
      26,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w800,
  );

  static TextStyle textStyleRobotoromansemibold361 =
      textStyleRobotoromansemibold36.copyWith();

  static TextStyle textStyleRobotoromanextrabold30 = TextStyle(
    color: ColorConstant.redA100,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w800,
  );

  static TextStyle textStyleRobotoitalicbold151 = TextStyle(
    color: ColorConstant.redA1007f,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle textStyleRobotoromanregular24 = TextStyle(
    color: ColorConstant.red900,
    fontSize: getFontSize(
      24,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle textStyleInterextrabold32 = TextStyle(
    color: ColorConstant.red900Bf,
    fontSize: getFontSize(
      32,
    ),
    fontFamily: 'Inter',
    fontWeight: FontWeight.w400,
  );
}
