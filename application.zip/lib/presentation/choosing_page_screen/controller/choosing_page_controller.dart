import '/core/app_export.dart';
import 'package:application/presentation/choosing_page_screen/models/choosing_page_model.dart';

class ChoosingPageController extends GetxController with StateMixin<dynamic> {
  Rx<ChoosingPageModel> choosingPageModelObj = ChoosingPageModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
