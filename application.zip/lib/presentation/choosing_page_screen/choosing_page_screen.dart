import 'controller/choosing_page_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class ChoosingPageScreen extends GetWidget<ChoosingPageController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Container(
                                      height: getVerticalSize(780.00),
                                      width: getHorizontalSize(345.00),
                                      margin: EdgeInsets.only(
                                          top: getVerticalSize(10.00),
                                          right: getHorizontalSize(15.00),
                                          bottom: getVerticalSize(10.00)),
                                      child: Stack(
                                          alignment: Alignment.topLeft,
                                          children: [
                                            Align(
                                                alignment:
                                                    Alignment.centerRight,
                                                child: Container(
                                                    width: getHorizontalSize(
                                                        330.00),
                                                    margin: EdgeInsets.only(
                                                        left: getHorizontalSize(
                                                            10.00)),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .red400,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    42.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Container(
                                                              width: double
                                                                  .infinity,
                                                              margin: EdgeInsets.only(
                                                                  left:
                                                                      getHorizontalSize(
                                                                          5.00),
                                                                  top: getVerticalSize(
                                                                      5.00),
                                                                  right:
                                                                      getHorizontalSize(
                                                                          5.00),
                                                                  bottom:
                                                                      getVerticalSize(
                                                                          5.00)),
                                                              decoration: BoxDecoration(
                                                                  color:
                                                                      ColorConstant
                                                                          .red50,
                                                                  borderRadius:
                                                                      BorderRadius.circular(
                                                                          getHorizontalSize(
                                                                              42.00))),
                                                              child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Align(
                                                                        alignment:
                                                                            Alignment.centerLeft,
                                                                        child: Padding(
                                                                            padding: EdgeInsets.only(top: getVerticalSize(43.00)),
                                                                            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.max, children: [
                                                                              Padding(padding: EdgeInsets.only(left: getHorizontalSize(35.00), top: getVerticalSize(134.00)), child: Text("lbl_exit".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.textStyleRobotoromanextrabold26.copyWith(fontSize: getFontSize(26), decoration: TextDecoration.underline))),
                                                                              Padding(
                                                                                  padding: EdgeInsets.only(right: getHorizontalSize(13.46)),
                                                                                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.start, children: [
                                                                                    GestureDetector(
                                                                                        onTap: () {
                                                                                          onTapImgGroup4();
                                                                                        },
                                                                                        child: Image.asset(ImageConstant.imgGroup4, height: getVerticalSize(134.17), width: getHorizontalSize(148.54), fit: BoxFit.fill)),
                                                                                    Padding(padding: EdgeInsets.only(left: getHorizontalSize(2.00), right: getHorizontalSize(10.00)), child: Text("lbl_daily_card".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.textStyleRobotoromanextrabold26.copyWith(fontSize: getFontSize(26), decoration: TextDecoration.underline)))
                                                                                  ]))
                                                                            ]))),
                                                                    GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          onTapImgEllipse13();
                                                                        },
                                                                        child: Padding(
                                                                            padding: EdgeInsets.only(
                                                                                left: getHorizontalSize(54.00),
                                                                                top: getVerticalSize(62.00),
                                                                                right: getHorizontalSize(54.00)),
                                                                            child: ClipRRect(borderRadius: BorderRadius.circular(getSize(75.00)), child: Image.asset(ImageConstant.imgEllipse13, height: getSize(150.00), width: getSize(150.00), fit: BoxFit.fill)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                54.00),
                                                                            top: getVerticalSize(
                                                                                18.00),
                                                                            right: getHorizontalSize(
                                                                                54.00)),
                                                                        child: Text(
                                                                            "lbl_emergency"
                                                                                .tr
                                                                                .toUpperCase(),
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanextrabold36.copyWith(fontSize: getFontSize(36), decoration: TextDecoration.underline))),
                                                                    GestureDetector(
                                                                        onTap:
                                                                            () {
                                                                          onTapImgEllipse14();
                                                                        },
                                                                        child: Padding(
                                                                            padding: EdgeInsets.only(
                                                                                left: getHorizontalSize(54.00),
                                                                                top: getVerticalSize(44.00),
                                                                                right: getHorizontalSize(54.00)),
                                                                            child: ClipRRect(borderRadius: BorderRadius.circular(getSize(75.00)), child: Image.asset(ImageConstant.imgEllipse14, height: getSize(150.00), width: getSize(150.00), fit: BoxFit.fill)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                54.00),
                                                                            top: getVerticalSize(
                                                                                18.00),
                                                                            right: getHorizontalSize(
                                                                                54.00),
                                                                            bottom: getVerticalSize(
                                                                                20.00)),
                                                                        child: Text(
                                                                            "lbl_symptoms"
                                                                                .tr
                                                                                .toUpperCase(),
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanextrabold36.copyWith(fontSize: getFontSize(36), decoration: TextDecoration.underline)))
                                                                  ]))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: Container(
                                                    height: getSize(165.00),
                                                    width: getSize(165.00),
                                                    margin: EdgeInsets.only(
                                                        top: getVerticalSize(
                                                            41.00),
                                                        right:
                                                            getHorizontalSize(
                                                                10.00),
                                                        bottom: getVerticalSize(
                                                            41.00)),
                                                    child: Stack(
                                                        alignment: Alignment
                                                            .centerLeft,
                                                        children: [
                                                          Align(
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              child: Container(
                                                                  height:
                                                                      getSize(
                                                                          97.06),
                                                                  width: getSize(
                                                                      97.06),
                                                                  margin: EdgeInsets.only(
                                                                      left: getHorizontalSize(
                                                                          34.94),
                                                                      top: getVerticalSize(
                                                                          33.00),
                                                                      right: getHorizontalSize(
                                                                          33.00),
                                                                      bottom: getVerticalSize(
                                                                          34.94)),
                                                                  decoration: BoxDecoration(
                                                                      color: ColorConstant
                                                                          .deepOrange100,
                                                                      borderRadius:
                                                                          BorderRadius.circular(
                                                                              getHorizontalSize(48.53))))),
                                                          Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child: Container(
                                                                  height: getSize(
                                                                      165.00),
                                                                  width: getSize(
                                                                      165.00),
                                                                  child: Stack(
                                                                      alignment:
                                                                          Alignment
                                                                              .center,
                                                                      children: [
                                                                        Align(
                                                                            alignment:
                                                                                Alignment.centerLeft,
                                                                            child: GestureDetector(
                                                                                onTap: () {
                                                                                  onTapImgReturnPNG5();
                                                                                },
                                                                                child: ClipRRect(borderRadius: BorderRadius.circular(getHorizontalSize(82.50)), child: Image.asset(ImageConstant.imgReturnpng5, height: getSize(165.00), width: getSize(165.00), fit: BoxFit.fill)))),
                                                                        Align(
                                                                            alignment: Alignment
                                                                                .center,
                                                                            child: Container(
                                                                                height: getVerticalSize(97.06),
                                                                                width: getHorizontalSize(99.00),
                                                                                margin: EdgeInsets.only(left: getHorizontalSize(33.00), top: getVerticalSize(33.00), right: getHorizontalSize(33.00), bottom: getVerticalSize(34.94)),
                                                                                decoration: BoxDecoration(color: ColorConstant.redA100, borderRadius: BorderRadius.circular(getHorizontalSize(82.50)))))
                                                                      ])))
                                                        ])))
                                          ])))
                            ]))))));
  }

  onTapImgGroup4() {
    Get.toNamed(AppRoutes.dailyCardsFinal1Screen);
  }

  onTapImgEllipse13() {
    Get.toNamed(AppRoutes.emergencyPageScreen);
  }

  onTapImgEllipse14() {
    Get.toNamed(AppRoutes.signUpOrLoginScreen);
  }

  onTapImgReturnPNG5() {
    Get.toNamed(AppRoutes.androidLarge1Screen);
  }
}
