import '/core/app_export.dart';
import 'package:application/presentation/cuts_card_screen/models/cuts_card_model.dart';

class CutsCardController extends GetxController with StateMixin<dynamic> {
  Rx<CutsCardModel> cutsCardModelObj = CutsCardModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
