import '../controller/daily_cards_final_3_controller.dart';
import 'package:get/get.dart';

class DailyCardsFinal3Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DailyCardsFinal3Controller());
  }
}
