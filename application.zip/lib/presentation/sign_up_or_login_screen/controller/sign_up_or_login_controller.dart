import '/core/app_export.dart';
import 'package:application/presentation/sign_up_or_login_screen/models/sign_up_or_login_model.dart';

class SignUpOrLoginController extends GetxController with StateMixin<dynamic> {
  Rx<SignUpOrLoginModel> signUpOrLoginModelObj = SignUpOrLoginModel().obs;

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
