import 'package:get/get.dart';
import 'emergency_page_item_model.dart';

class EmergencyPageModel {
  RxList<EmergencyPageItemModel> emergencyPageItemList =
      RxList.filled(4, EmergencyPageItemModel());
}
