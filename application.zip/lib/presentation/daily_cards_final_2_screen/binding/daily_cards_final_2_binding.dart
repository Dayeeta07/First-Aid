import '../controller/daily_cards_final_2_controller.dart';
import 'package:get/get.dart';

class DailyCardsFinal2Binding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => DailyCardsFinal2Controller());
  }
}
