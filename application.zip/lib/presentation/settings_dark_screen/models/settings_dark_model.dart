class SettingsDarkModel {}
