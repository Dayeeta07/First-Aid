import '../controller/sign_up_or_login_controller.dart';
import 'package:get/get.dart';

class SignUpOrLoginBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => SignUpOrLoginController());
  }
}
