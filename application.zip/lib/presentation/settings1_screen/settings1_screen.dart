import 'controller/settings1_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Settings1Screen extends GetWidget<Settings1Controller> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: getHorizontalSize(372.00),
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: size.height,
                                  width: size.width,
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(6.00),
                                      right: getHorizontalSize(6.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red50,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))))),
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: getVerticalSize(780.00),
                                  width: getHorizontalSize(330.00),
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(21.00),
                                      top: getVerticalSize(10.00),
                                      right: getHorizontalSize(21.00),
                                      bottom: getVerticalSize(10.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red400,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))),
                                  child: Card(
                                      clipBehavior: Clip.antiAlias,
                                      elevation: 0,
                                      margin: EdgeInsets.all(0),
                                      color: ColorConstant.red400,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              getHorizontalSize(42.00))),
                                      child: Stack(
                                          alignment: Alignment.topLeft,
                                          children: [
                                            Align(
                                                alignment: Alignment.center,
                                                child: Container(
                                                    margin: EdgeInsets.only(
                                                        left: getHorizontalSize(
                                                            5.00),
                                                        top: getVerticalSize(
                                                            5.00),
                                                        right:
                                                            getHorizontalSize(
                                                                5.00),
                                                        bottom: getVerticalSize(
                                                            5.00)),
                                                    decoration: BoxDecoration(
                                                        color:
                                                            ColorConstant.red50,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                                getHorizontalSize(
                                                                    42.00))),
                                                    child: Column(
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: [
                                                          Padding(
                                                              padding: EdgeInsets.only(
                                                                  top: getVerticalSize(
                                                                      19.00)),
                                                              child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Align(
                                                                        alignment:
                                                                            Alignment
                                                                                .centerLeft,
                                                                        child: Container(
                                                                            height:
                                                                                getVerticalSize(51.00),
                                                                            width: getHorizontalSize(53.00),
                                                                            margin: EdgeInsets.only(left: getHorizontalSize(14.00), right: getHorizontalSize(14.00)),
                                                                            decoration: BoxDecoration(color: ColorConstant.red50, borderRadius: BorderRadius.circular(getHorizontalSize(25.50))))),
                                                                    Align(
                                                                        alignment:
                                                                            Alignment
                                                                                .centerLeft,
                                                                        child: Padding(
                                                                            padding:
                                                                                EdgeInsets.only(top: getVerticalSize(56.00), right: getHorizontalSize(10.00)),
                                                                            child: Text("lbl_appearance".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24))))),
                                                                    Align(
                                                                        alignment:
                                                                            Alignment.centerLeft,
                                                                        child: Padding(
                                                                            padding: EdgeInsets.only(top: getVerticalSize(18.00)),
                                                                            child: Row(mainAxisAlignment: MainAxisAlignment.start, crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.max, children: [
                                                                              Padding(padding: EdgeInsets.only(left: getHorizontalSize(26.00), top: getVerticalSize(2.00), bottom: getVerticalSize(3.12)), child: Text("lbl_light".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanregular16.copyWith(fontSize: getFontSize(16)))),
                                                                              Container(
                                                                                  height: getVerticalSize(24.12),
                                                                                  width: getHorizontalSize(60.00),
                                                                                  margin: EdgeInsets.only(left: getHorizontalSize(10.00)),
                                                                                  child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                    Align(alignment: Alignment.centerLeft, child: Switch(value: false, inactiveTrackColor: ColorConstant.red400, inactiveThumbColor: ColorConstant.deepOrange200, onChanged: (rating) {})),
                                                                                    Align(alignment: Alignment.centerLeft, child: Container(height: getSize(2.47), width: getSize(2.47), margin: EdgeInsets.only(left: getHorizontalSize(0.74), top: getVerticalSize(10.76), right: getHorizontalSize(10.00), bottom: getVerticalSize(10.76)), decoration: BoxDecoration(color: ColorConstant.red400, borderRadius: BorderRadius.circular(getHorizontalSize(1.24)))))
                                                                                  ])),
                                                                              Padding(padding: EdgeInsets.only(left: getHorizontalSize(10.00), top: getVerticalSize(2.00), right: getHorizontalSize(145.00), bottom: getVerticalSize(3.12)), child: Text("lbl_dark".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanregular16.copyWith(fontSize: getFontSize(16))))
                                                                            ]))),
                                                                    Align(
                                                                        alignment:
                                                                            Alignment
                                                                                .centerLeft,
                                                                        child: Padding(
                                                                            padding:
                                                                                EdgeInsets.only(top: getVerticalSize(42.88), right: getHorizontalSize(10.00)),
                                                                            child: Text("lbl_font_size".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.left, style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24)))))
                                                                  ])),
                                                          Padding(
                                                              padding: EdgeInsets.only(
                                                                  top: getVerticalSize(
                                                                      29.00)),
                                                              child: Row(
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .max,
                                                                  children: [
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                24.00),
                                                                            top: getVerticalSize(
                                                                                3.00),
                                                                            bottom: getVerticalSize(
                                                                                2.00)),
                                                                        child: Text(
                                                                            "lbl_small"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.center,
                                                                            style: AppStyle.textStyleRobotoromanregular16.copyWith(fontSize: getFontSize(16)))),
                                                                    Container(
                                                                        height: getVerticalSize(
                                                                            24.00),
                                                                        width: getHorizontalSize(
                                                                            70.00),
                                                                        margin: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                24.00)),
                                                                        child: Stack(
                                                                            alignment:
                                                                                Alignment.centerLeft,
                                                                            children: [
                                                                              Align(alignment: Alignment.bottomCenter, child: Padding(padding: EdgeInsets.only(left: getHorizontalSize(5.00), top: getVerticalSize(10.00), right: getHorizontalSize(6.00), bottom: getVerticalSize(2.00)), child: Text("lbl_medium".tr, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanregular16.copyWith(fontSize: getFontSize(16))))),
                                                                              Align(alignment: Alignment.centerLeft, child: Container(height: getVerticalSize(24.00), width: getHorizontalSize(70.00), decoration: BoxDecoration(borderRadius: BorderRadius.circular(getHorizontalSize(5.00)), gradient: LinearGradient(begin: Alignment(-0.014285654589838357, 2.737533826291383e-7), end: Alignment(1.0000000531119955, 1.0000001956294664), colors: [ColorConstant.redA100Bf, ColorConstant.redA10080]))))
                                                                            ])),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                19.00),
                                                                            top: getVerticalSize(
                                                                                3.00),
                                                                            right: getHorizontalSize(
                                                                                101.00),
                                                                            bottom: getVerticalSize(
                                                                                2.00)),
                                                                        child: Text(
                                                                            "lbl_large"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.center,
                                                                            style: AppStyle.textStyleRobotoromanregular16.copyWith(fontSize: getFontSize(16))))
                                                                  ])),
                                                          Padding(
                                                              padding: EdgeInsets.only(
                                                                  top: getVerticalSize(
                                                                      46.00),
                                                                  bottom:
                                                                      getVerticalSize(
                                                                          80.00)),
                                                              child: Column(
                                                                  mainAxisSize:
                                                                      MainAxisSize
                                                                          .min,
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .start,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: [
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                5.00),
                                                                            right: getHorizontalSize(
                                                                                10.00)),
                                                                        child: Text(
                                                                            "lbl_account"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                4.00),
                                                                            top: getVerticalSize(
                                                                                46.00),
                                                                            right: getHorizontalSize(
                                                                                10.00)),
                                                                        child: Text(
                                                                            "msg_privacy_and_sec"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                5.00),
                                                                            top: getVerticalSize(
                                                                                46.00),
                                                                            right: getHorizontalSize(
                                                                                10.00)),
                                                                        child: Text(
                                                                            "msg_help_and_suppor"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                5.00),
                                                                            top: getVerticalSize(
                                                                                46.00),
                                                                            right: getHorizontalSize(
                                                                                10.00)),
                                                                        child: Text(
                                                                            "lbl_about"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24)))),
                                                                    Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                9.00),
                                                                            top: getVerticalSize(
                                                                                46.00),
                                                                            right: getHorizontalSize(
                                                                                10.00)),
                                                                        child: Text(
                                                                            "lbl_logout"
                                                                                .tr,
                                                                            overflow:
                                                                                TextOverflow.ellipsis,
                                                                            textAlign: TextAlign.left,
                                                                            style: AppStyle.textStyleRobotoromanregular24.copyWith(fontSize: getFontSize(24))))
                                                                  ]))
                                                        ]))),
                                            Align(
                                                alignment: Alignment.topLeft,
                                                child: GestureDetector(
                                                    onTap: () {
                                                      onTapImgMaskgroup();
                                                    },
                                                    child: Padding(
                                                        padding: EdgeInsets.only(
                                                            left:
                                                                getHorizontalSize(
                                                                    3.00),
                                                            top:
                                                                getVerticalSize(
                                                                    5.00),
                                                            right:
                                                                getHorizontalSize(
                                                                    10.00),
                                                            bottom:
                                                                getVerticalSize(
                                                                    10.00)),
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    89.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    91.00),
                                                            child: SvgPicture.asset(
                                                                ImageConstant
                                                                    .imgMaskgroup8,
                                                                fit: BoxFit.fill)))))
                                          ]))))
                        ]))))));
  }

  onTapImgMaskgroup() {
    Get.toNamed(AppRoutes.symptomsPageScreen);
  }
}
