import 'controller/logo_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LogoScreen extends GetWidget<LogoController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: GestureDetector(
                        onTap: () {
                          onTapGroup457();
                        },
                        child: Container(
                            decoration:
                                BoxDecoration(color: ColorConstant.red50),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                      height: getVerticalSize(770.00),
                                      width: getHorizontalSize(350.00),
                                      margin: EdgeInsets.only(
                                          left: getHorizontalSize(5.00),
                                          top: getVerticalSize(15.00),
                                          right: getHorizontalSize(5.00),
                                          bottom: getVerticalSize(15.00)),
                                      decoration: BoxDecoration(
                                          color: ColorConstant.red400,
                                          borderRadius: BorderRadius.circular(
                                              getHorizontalSize(42.00))),
                                      child: Card(
                                          clipBehavior: Clip.antiAlias,
                                          elevation: 0,
                                          margin: EdgeInsets.all(0),
                                          color: ColorConstant.red400,
                                          shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      getHorizontalSize(
                                                          42.00))),
                                          child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: EdgeInsets.only(
                                                            left:
                                                                getHorizontalSize(
                                                                    15.00),
                                                            right:
                                                                getHorizontalSize(
                                                                    15.00)),
                                                        child: Container(
                                                            height:
                                                                getVerticalSize(
                                                                    770.00),
                                                            width:
                                                                getHorizontalSize(
                                                                    320.00),
                                                            child: SvgPicture.asset(
                                                                ImageConstant
                                                                    .imgFrame16,
                                                                fit: BoxFit
                                                                    .fill)))),
                                                Align(
                                                    alignment: Alignment.center,
                                                    child: Padding(
                                                        padding: EdgeInsets.only(
                                                            left: getHorizontalSize(
                                                                40.00),
                                                            top: getVerticalSize(
                                                                40.00),
                                                            right: getHorizontalSize(
                                                                40.00),
                                                            bottom: getVerticalSize(
                                                                40.00)),
                                                        child: ClipRRect(
                                                            borderRadius: BorderRadius.circular(
                                                                getSize(25.00)),
                                                            child: Container(
                                                                height: getSize(
                                                                    50.00),
                                                                width: getSize(
                                                                    50.00),
                                                                child: SvgPicture.asset(ImageConstant.imgTw,
                                                                    fit: BoxFit.fill))))),
                                                Align(
                                                    alignment:
                                                        Alignment.centerLeft,
                                                    child: Padding(
                                                        padding: EdgeInsets.only(
                                                            top:
                                                                getVerticalSize(
                                                                    210.00),
                                                            bottom:
                                                                getVerticalSize(
                                                                    210.00)),
                                                        child: Image.asset(
                                                            ImageConstant
                                                                .imgUntitled392022,
                                                            height:
                                                                getSize(350.00),
                                                            width:
                                                                getSize(350.00),
                                                            fit: BoxFit.fill)))
                                              ])))
                                ])))))));
  }

  onTapGroup457() {
    Get.toNamed(AppRoutes.loadingPageScreen);
  }
}
