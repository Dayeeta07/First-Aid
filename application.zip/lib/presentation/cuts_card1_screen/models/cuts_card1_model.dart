class CutsCard1Model {}
