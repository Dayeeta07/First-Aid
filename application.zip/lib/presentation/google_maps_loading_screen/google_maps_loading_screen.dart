import 'controller/google_maps_loading_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class GoogleMapsLoadingScreen extends GetWidget<GoogleMapsLoadingController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.whiteA700,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: GestureDetector(
                        onTap: () {
                          onTapGM();
                        },
                        child: Container(
                            decoration:
                                BoxDecoration(color: ColorConstant.whiteA700),
                            child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [])))))));
  }

  onTapGM() {
    Get.toNamed(AppRoutes.googleMapsScreen);
  }
}
