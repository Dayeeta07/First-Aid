import 'controller/cuts_card_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CutsCardScreen extends GetWidget<CutsCardController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Container(
                                            height: getVerticalSize(132.00),
                                            width: size.width,
                                            child: Stack(
                                                alignment: Alignment.centerLeft,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  132.00),
                                                          width:
                                                              getHorizontalSize(
                                                                  360.00),
                                                          child: SvgPicture.asset(
                                                              ImageConstant
                                                                  .imgMaskgroup3,
                                                              fit: BoxFit
                                                                  .fill))),
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          decoration: BoxDecoration(
                                                              color: ColorConstant
                                                                  .red400,
                                                              borderRadius: BorderRadius.only(
                                                                  topLeft: Radius.circular(
                                                                      getHorizontalSize(
                                                                          42.00)),
                                                                  topRight: Radius.circular(
                                                                      getHorizontalSize(
                                                                          42.00)),
                                                                  bottomLeft: Radius.circular(
                                                                      getHorizontalSize(
                                                                          0.00)),
                                                                  bottomRight:
                                                                      Radius.circular(
                                                                          getHorizontalSize(0.00)))),
                                                          child: Row(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.max, children: [
                                                            Padding(
                                                                padding: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        14.00),
                                                                    top: getVerticalSize(
                                                                        20.00),
                                                                    bottom: getVerticalSize(
                                                                        18.00)),
                                                                child: Column(
                                                                    mainAxisSize:
                                                                        MainAxisSize
                                                                            .min,
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .end,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .start,
                                                                    children: [
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .centerLeft,
                                                                          child: Row(
                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                                              mainAxisSize: MainAxisSize.max,
                                                                              children: [
                                                                                Container(
                                                                                    height: getSize(53.00),
                                                                                    width: getSize(53.00),
                                                                                    margin: EdgeInsets.only(bottom: getVerticalSize(12.00)),
                                                                                    child: Stack(alignment: Alignment.centerLeft, children: [
                                                                                      Align(alignment: Alignment.center, child: Container(height: getSize(37.00), width: getSize(37.00), margin: EdgeInsets.only(left: getHorizontalSize(9.00), top: getVerticalSize(7.00), right: getHorizontalSize(7.00), bottom: getVerticalSize(9.00)), decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))))),
                                                                                      Align(
                                                                                          alignment: Alignment.centerLeft,
                                                                                          child: Container(
                                                                                              height: getSize(53.00),
                                                                                              width: getSize(53.00),
                                                                                              child: Stack(alignment: Alignment.center, children: [
                                                                                                Align(
                                                                                                    alignment: Alignment.centerLeft,
                                                                                                    child: GestureDetector(
                                                                                                        onTap: () {
                                                                                                          onTapImgMenuPNG1();
                                                                                                        },
                                                                                                        child: Image.asset(ImageConstant.imgMenupng1, height: getSize(53.00), width: getSize(53.00), fit: BoxFit.fill))),
                                                                                                Align(alignment: Alignment.center, child: Container(height: getVerticalSize(41.00), width: getHorizontalSize(45.00), margin: EdgeInsets.only(left: getHorizontalSize(5.00), top: getVerticalSize(5.00), right: getHorizontalSize(3.00), bottom: getVerticalSize(7.00)), decoration: BoxDecoration(color: ColorConstant.red900, borderRadius: BorderRadius.circular(getHorizontalSize(26.00)))))
                                                                                              ])))
                                                                                    ])),
                                                                                Padding(padding: EdgeInsets.only(left: getHorizontalSize(68.00), top: getVerticalSize(27.00), right: getHorizontalSize(66.00)), child: Text("lbl_cuts2".tr.toUpperCase(), overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: AppStyle.textStyleRobotoromanblack32.copyWith(fontSize: getFontSize(32))))
                                                                              ])),
                                                                      Padding(
                                                                          padding: EdgeInsets.only(
                                                                              left: getHorizontalSize(
                                                                                  10.00),
                                                                              top: getVerticalSize(
                                                                                  10.00)),
                                                                          child: Text(
                                                                              "msg_by".tr.toUpperCase(),
                                                                              overflow: TextOverflow.ellipsis,
                                                                              textAlign: TextAlign.center,
                                                                              style: AppStyle.textStyleRobotoromanblack16.copyWith(fontSize: getFontSize(16))))
                                                                    ])),
                                                            Container(
                                                                height:
                                                                    getVerticalSize(
                                                                        65.00),
                                                                width:
                                                                    getHorizontalSize(
                                                                        63.00),
                                                                margin: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        1.00),
                                                                    top: getVerticalSize(
                                                                        8.00),
                                                                    right: getHorizontalSize(
                                                                        12.00),
                                                                    bottom: getVerticalSize(
                                                                        59.00)),
                                                                child: Stack(
                                                                    alignment:
                                                                        Alignment
                                                                            .centerLeft,
                                                                    children: [
                                                                      Align(
                                                                          alignment: Alignment
                                                                              .center,
                                                                          child: Container(
                                                                              height: getSize(37.00),
                                                                              width: getSize(37.00),
                                                                              margin: EdgeInsets.only(left: getHorizontalSize(13.00), top: getVerticalSize(14.00), right: getHorizontalSize(13.00), bottom: getVerticalSize(14.00)),
                                                                              decoration: BoxDecoration(color: ColorConstant.whiteA700, borderRadius: BorderRadius.circular(getHorizontalSize(18.50))))),
                                                                      Align(
                                                                          alignment:
                                                                              Alignment.centerLeft,
                                                                          child: GestureDetector(
                                                                              onTap: () {
                                                                                onTapImgMaskgroup();
                                                                              },
                                                                              child: Container(height: getVerticalSize(65.00), width: getHorizontalSize(63.00), child: SvgPicture.asset(ImageConstant.imgMaskgroup4, fit: BoxFit.fill))))
                                                                    ]))
                                                          ])))
                                                ])),
                                        Align(
                                            alignment: Alignment.center,
                                            child: Container(
                                                width: double.infinity,
                                                margin: EdgeInsets.only(
                                                    left: getHorizontalSize(
                                                        41.00),
                                                    top: getVerticalSize(36.00),
                                                    right: getHorizontalSize(
                                                        39.00)),
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            getHorizontalSize(
                                                                10.00)),
                                                    gradient: LinearGradient(
                                                        begin: Alignment(0.5,
                                                            -3.0616171314629196e-17),
                                                        end: Alignment(0.5,
                                                            0.9999999999999999),
                                                        colors: [
                                                          ColorConstant
                                                              .deepOrange100,
                                                          ColorConstant
                                                              .deepOrange10000,
                                                          ColorConstant
                                                              .deepOrange100
                                                        ])),
                                                child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                          width:
                                                              getHorizontalSize(
                                                                  262.00),
                                                          margin: EdgeInsets.only(
                                                              left: getHorizontalSize(
                                                                  7.00),
                                                              top:
                                                                  getVerticalSize(
                                                                      19.00),
                                                              right:
                                                                  getHorizontalSize(
                                                                      11.00)),
                                                          child: Text(
                                                              "msg_adipiscing_elit"
                                                                  .tr,
                                                              maxLines: null,
                                                              textAlign:
                                                                  TextAlign
                                                                      .center,
                                                              style: AppStyle
                                                                  .textStyleInterregular24
                                                                  .copyWith(
                                                                      fontSize:
                                                                          getFontSize(
                                                                              24))))
                                                    ]))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                top: getVerticalSize(25.00)),
                                            child: Column(
                                                mainAxisSize: MainAxisSize.min,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: [
                                                  Align(
                                                      alignment:
                                                          Alignment.centerLeft,
                                                      child: Container(
                                                          height:
                                                              getSize(16.00),
                                                          width: getSize(16.00),
                                                          margin: EdgeInsets.only(
                                                              left:
                                                                  getHorizontalSize(
                                                                      140.00),
                                                              right:
                                                                  getHorizontalSize(
                                                                      140.00)),
                                                          decoration: BoxDecoration(
                                                              color:
                                                                  ColorConstant
                                                                      .red900,
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(
                                                                          8.00))))),
                                                  Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Container(
                                                          height:
                                                              getVerticalSize(
                                                                  5.00),
                                                          width: getHorizontalSize(
                                                              300.00),
                                                          margin: EdgeInsets.only(
                                                              left:
                                                                  getHorizontalSize(
                                                                      30.00),
                                                              right:
                                                                  getHorizontalSize(
                                                                      30.00)),
                                                          decoration: BoxDecoration(
                                                              border: Border.all(
                                                                  color:
                                                                      ColorConstant
                                                                          .red900,
                                                                  width: getHorizontalSize(
                                                                      5.00)))))
                                                ])),
                                        Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Padding(
                                                  padding: EdgeInsets.only(
                                                      left: getHorizontalSize(
                                                          30.00)),
                                                  child: Text(
                                                      "lbl".tr.toUpperCase(),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: AppStyle
                                                          .textStyleRobotoromanblack20
                                                          .copyWith(
                                                              fontSize:
                                                                  getFontSize(
                                                                      20)))),
                                              Padding(
                                                  padding: EdgeInsets.only(
                                                      right: getHorizontalSize(
                                                          30.00)),
                                                  child: Text(
                                                      "lbl".tr.toUpperCase(),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: AppStyle
                                                          .textStyleRobotoromanblack20
                                                          .copyWith(
                                                              fontSize:
                                                                  getFontSize(
                                                                      20))))
                                            ]),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                top: getVerticalSize(13.00)),
                                            child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Container(
                                                      margin: EdgeInsets.only(
                                                          left:
                                                              getHorizontalSize(
                                                                  38.00),
                                                          top: getVerticalSize(
                                                              20.00),
                                                          bottom:
                                                              getVerticalSize(
                                                                  20.00)),
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .deepOrange100,
                                                          borderRadius:
                                                              BorderRadius.circular(
                                                                  getHorizontalSize(
                                                                      25.00))),
                                                      child: Column(
                                                          mainAxisSize:
                                                              MainAxisSize.min,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Container(
                                                                height: getSize(
                                                                    20.00),
                                                                width: getSize(
                                                                    20.00),
                                                                margin: EdgeInsets.only(
                                                                    left: getHorizontalSize(
                                                                        15.00),
                                                                    top: getVerticalSize(
                                                                        15.00),
                                                                    right: getHorizontalSize(
                                                                        15.00),
                                                                    bottom: getVerticalSize(
                                                                        15.00)),
                                                                decoration: BoxDecoration(
                                                                    color: ColorConstant
                                                                        .red400))
                                                          ])),
                                                  Container(
                                                      height: getSize(90.00),
                                                      width: getSize(90.00),
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .red500,
                                                          borderRadius:
                                                              BorderRadius.circular(
                                                                  getHorizontalSize(
                                                                      45.00))),
                                                      child: Card(
                                                          clipBehavior:
                                                              Clip.antiAlias,
                                                          elevation: 0,
                                                          margin:
                                                              EdgeInsets.all(0),
                                                          color: ColorConstant
                                                              .red500,
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(
                                                                          45.00))),
                                                          child: Stack(
                                                              children: [
                                                                Align(
                                                                    alignment:
                                                                        Alignment
                                                                            .center,
                                                                    child: Padding(
                                                                        padding: EdgeInsets.only(
                                                                            left: getHorizontalSize(
                                                                                20.00),
                                                                            top: getVerticalSize(
                                                                                20.00),
                                                                            right: getHorizontalSize(
                                                                                20.00),
                                                                            bottom: getVerticalSize(
                                                                                20.00)),
                                                                        child: Image.asset(
                                                                            ImageConstant
                                                                                .imgPolygon1,
                                                                            height:
                                                                                getSize(50.00),
                                                                            width: getSize(50.00),
                                                                            fit: BoxFit.fill)))
                                                              ]))),
                                                  Container(
                                                      height: getSize(50.00),
                                                      width: getSize(50.00),
                                                      margin: EdgeInsets.only(
                                                          top: getVerticalSize(
                                                              20.00),
                                                          right: getHorizontalSize(
                                                              36.00),
                                                          bottom: getVerticalSize(
                                                              20.00)),
                                                      decoration: BoxDecoration(
                                                          color: ColorConstant
                                                              .deepOrange100,
                                                          borderRadius:
                                                              BorderRadius.circular(
                                                                  getHorizontalSize(
                                                                      25.00))),
                                                      child: Card(
                                                          clipBehavior:
                                                              Clip.antiAlias,
                                                          elevation: 0,
                                                          margin:
                                                              EdgeInsets.all(0),
                                                          color: ColorConstant
                                                              .deepOrange100,
                                                          shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      getHorizontalSize(25.00))),
                                                          child: Stack(children: [
                                                            Align(
                                                                alignment: Alignment
                                                                    .centerRight,
                                                                child: Padding(
                                                                    padding: EdgeInsets.only(
                                                                        left: getHorizontalSize(
                                                                            10.00),
                                                                        top: getVerticalSize(
                                                                            15.31),
                                                                        right: getHorizontalSize(
                                                                            7.00),
                                                                        bottom: getVerticalSize(
                                                                            15.31)),
                                                                    child: Container(
                                                                        height: getVerticalSize(
                                                                            18.69),
                                                                        width: getHorizontalSize(
                                                                            30.00),
                                                                        child: SvgPicture.asset(
                                                                            ImageConstant
                                                                                .imgUnion,
                                                                            fit:
                                                                                BoxFit.fill))))
                                                          ])))
                                                ]))
                                      ])),
                              Container(
                                  height: getVerticalSize(50.00),
                                  width: getHorizontalSize(300.00),
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(30.00),
                                      top: getVerticalSize(19.00),
                                      right: getHorizontalSize(30.00)),
                                  child: Stack(
                                      alignment: Alignment.centerLeft,
                                      children: [
                                        Align(
                                            alignment: Alignment.center,
                                            child: GestureDetector(
                                                onTap: () {
                                                  onTapGM();
                                                },
                                                child: Container(
                                                    height:
                                                        getVerticalSize(40.00),
                                                    width: getHorizontalSize(
                                                        280.00),
                                                    margin: EdgeInsets.only(
                                                        left: getHorizontalSize(
                                                            11.00),
                                                        top: getVerticalSize(
                                                            5.00),
                                                        right:
                                                            getHorizontalSize(
                                                                9.00),
                                                        bottom: getVerticalSize(
                                                            5.00)),
                                                    decoration: BoxDecoration(
                                                        color: ColorConstant
                                                            .whiteA700)))),
                                        Align(
                                            alignment: Alignment.centerLeft,
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(50.00),
                                                width:
                                                    getHorizontalSize(300.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromanblack201,
                                                child: Text("msg".tr,
                                                    textAlign: TextAlign.center,
                                                    style: AppStyle
                                                        .textStyleRobotoromanblack201
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    20)))))
                                      ])),
                              Padding(
                                  padding: EdgeInsets.only(
                                      left: getHorizontalSize(30.00),
                                      top: getVerticalSize(8.00),
                                      right: getHorizontalSize(30.00),
                                      bottom: getVerticalSize(19.00)),
                                  child: Text(
                                      "msg_nearest_healthc".tr.toUpperCase(),
                                      overflow: TextOverflow.ellipsis,
                                      textAlign: TextAlign.center,
                                      style: AppStyle
                                          .textStyleRobotoromanblack161
                                          .copyWith(fontSize: getFontSize(16))))
                            ]))))));
  }

  onTapImgMenuPNG1() {
    Get.toNamed(AppRoutes.menuScreen);
  }

  onTapImgMaskgroup() {
    Get.toNamed(AppRoutes.emergencyPageScreen);
  }

  onTapGM() {
    Get.toNamed(AppRoutes.googleMapsLoadingScreen);
  }
}
