import 'controller/sign_up_or_login_controller.dart';
import 'package:application/core/app_export.dart';
import 'package:flutter/material.dart';

class SignUpOrLoginScreen extends GetWidget<SignUpOrLoginController> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            backgroundColor: ColorConstant.red50,
            body: Container(
                width: size.width,
                child: SingleChildScrollView(
                    child: Container(
                        height: size.height,
                        width: size.width,
                        decoration: BoxDecoration(color: ColorConstant.red50),
                        child: Stack(alignment: Alignment.center, children: [
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  height: getVerticalSize(780.00),
                                  width: getHorizontalSize(330.00),
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(15.00),
                                      top: getVerticalSize(10.00),
                                      right: getHorizontalSize(15.00),
                                      bottom: getVerticalSize(10.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red400,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))))),
                          Align(
                              alignment: Alignment.center,
                              child: Container(
                                  margin: EdgeInsets.only(
                                      left: getHorizontalSize(20.00),
                                      top: getVerticalSize(15.00),
                                      right: getHorizontalSize(20.00),
                                      bottom: getVerticalSize(15.00)),
                                  decoration: BoxDecoration(
                                      color: ColorConstant.red50,
                                      borderRadius: BorderRadius.circular(
                                          getHorizontalSize(42.00))),
                                  child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        Container(
                                            width: getHorizontalSize(261.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(83.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: Text("msg_thank_you_fo".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .textStyleRobotoromanextrabold35
                                                    .copyWith(
                                                        fontSize:
                                                            getFontSize(35)))),
                                        Container(
                                            width: getHorizontalSize(209.00),
                                            margin: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(12.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: Text(
                                                "msg_we_aim_to_be_yo".tr,
                                                maxLines: null,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .textStyleRobotoitalicbold15
                                                    .copyWith(
                                                        fontSize:
                                                            getFontSize(15)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(82.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: Text(
                                                "msg_join_our_family".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .textStyleRobotoromanextrabold30
                                                    .copyWith(
                                                        fontSize:
                                                            getFontSize(30)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(14.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: GestureDetector(
                                                onTap: () {
                                                  onTapBtnSignup();
                                                },
                                                child: Container(
                                                    alignment: Alignment.center,
                                                    height:
                                                        getVerticalSize(85.00),
                                                    width: getHorizontalSize(
                                                        260.00),
                                                    decoration: AppDecoration
                                                        .textStyleRobotoromanextrabold351,
                                                    child: Text(
                                                        "lbl_sign_up".tr,
                                                        textAlign:
                                                            TextAlign.center,
                                                        style: AppStyle
                                                            .textStyleRobotoromanextrabold351
                                                            .copyWith(
                                                                fontSize:
                                                                    getFontSize(
                                                                        35)))))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(30.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: Text("lbl_or".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .textStyleRobotoromanextrabold25
                                                    .copyWith(
                                                        fontSize:
                                                            getFontSize(25)))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(44.00),
                                                right:
                                                    getHorizontalSize(29.00)),
                                            child: Container(
                                                alignment: Alignment.center,
                                                height: getVerticalSize(85.00),
                                                width:
                                                    getHorizontalSize(260.00),
                                                decoration: AppDecoration
                                                    .textStyleRobotoromanextrabold351,
                                                child: Text("lbl_login".tr,
                                                    textAlign: TextAlign.center,
                                                    style: AppStyle
                                                        .textStyleRobotoromanextrabold351
                                                        .copyWith(
                                                            fontSize:
                                                                getFontSize(
                                                                    35))))),
                                        Padding(
                                            padding: EdgeInsets.only(
                                                left: getHorizontalSize(29.00),
                                                top: getVerticalSize(47.00),
                                                right: getHorizontalSize(29.00),
                                                bottom: getVerticalSize(47.00)),
                                            child: Text(
                                                "msg_why_should_i_si".tr,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.center,
                                                style: AppStyle
                                                    .textStyleRobotoromanextrabold15
                                                    .copyWith(
                                                        fontSize:
                                                            getFontSize(15))))
                                      ])))
                        ]))))));
  }

  onTapBtnSignup() {
    Get.toNamed(AppRoutes.signUpScreen);
  }
}
