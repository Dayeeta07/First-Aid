import '../controller/emergency_page_controller.dart';
import 'package:get/get.dart';

class EmergencyPageBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => EmergencyPageController());
  }
}
